import React, { useState, useEffect } from 'react';
import { Clock, Sun, CloudRain, CloudSnow, Wind, Landmark } from 'lucide-react';

export default function WidgetPortal() {
  const [activeWidget, setActiveWidget] = useState('clock');
  
  // World Clock state
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTimezone = (offset) => {
    // Get time in UTC
    const utc = time.getTime() + time.getTimezoneOffset() * 60000;
    // Apply offset
    const localTime = new Date(utc + 3600000 * offset);
    return localTime.toLocaleTimeString('id-ID', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  };

  const formatDatezone = (offset) => {
    const utc = time.getTime() + time.getTimezoneOffset() * 60000;
    const localTime = new Date(utc + 3600000 * offset);
    return localTime.toLocaleDateString('id-ID', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  };

  // Weather simulator
  const [city, setCity] = useState('Jakarta');
  const [temp, setTemp] = useState(31);
  const [weatherType, setWeatherType] = useState('Sunny');
  const [wind, setWind] = useState(12);

  const citiesWeather = {
    Jakarta: { t: 32, w: 'Sunny', s: 14 },
    Tangerang: { t: 31, w: 'Cloudy', s: 12 },
    Bandung: { t: 24, w: 'Rainy', s: 10 },
    Tokyo: { t: 18, w: 'Sunny', s: 8 },
    London: { t: 12, w: 'Rainy', s: 20 },
    StMoritz: { t: -2, w: 'Snowy', s: 15 }
  };

  useEffect(() => {
    const data = citiesWeather[city];
    if (data) {
      setTemp(data.t);
      setWeatherType(data.w);
      setWind(data.s);
    }
  }, [city]);

  // Rates exchange simulator
  const [baseAmount, setBaseAmount] = useState(1);
  const [selectedRate, setSelectedRate] = useState('IDR');
  
  const exchangeRates = {
    IDR: 16420,
    EUR: 0.93,
    JPY: 161.4,
    GBP: 0.79,
    SGD: 1.35,
    AUD: 1.51
  };

  return (
    <div id="widget-portal-root" className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 max-w-xl mx-auto">
      {/* Widget selector tabs */}
      <div className="flex gap-2 mb-6 border-b border-slate-100 pb-3">
        <button
          onClick={() => setActiveWidget('clock')}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all ${
            activeWidget === 'clock' ? 'bg-emerald-500 text-white shadow-sm' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
          }`}
        >
          World Clock
        </button>
        <button
          onClick={() => setActiveWidget('weather')}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all ${
            activeWidget === 'weather' ? 'bg-emerald-500 text-white shadow-sm' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
          }`}
        >
          Weather Simulator
        </button>
        <button
          onClick={() => setActiveWidget('rates')}
          className={`px-4 py-2 rounded-xl text-xs font-bold uppercase transition-all ${
            activeWidget === 'rates' ? 'bg-emerald-500 text-white shadow-sm' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
          }`}
        >
          Currency Rates
        </button>
      </div>

      {activeWidget === 'clock' && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-4 h-4 text-emerald-500" />
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Waktu Dunia Real-Time</h4>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {/* Jakarta */}
            <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex flex-col items-center text-center shadow-sm">
              <span className="text-xs text-emerald-600 font-bold tracking-wider uppercase">Jakarta (WIB)</span>
              <span className="text-2xl font-mono font-bold text-slate-800 my-1">{formatTimezone(7)}</span>
              <span className="text-[10px] text-slate-500">{formatDatezone(7)}</span>
            </div>

            {/* Tokyo */}
            <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex flex-col items-center text-center shadow-sm">
              <span className="text-xs text-sky-600 font-bold tracking-wider uppercase">Tokyo (JST)</span>
              <span className="text-2xl font-mono font-bold text-slate-800 my-1">{formatTimezone(9)}</span>
              <span className="text-[10px] text-slate-500">{formatDatezone(9)}</span>
            </div>

            {/* London */}
            <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex flex-col items-center text-center shadow-sm">
              <span className="text-xs text-indigo-600 font-bold tracking-wider uppercase">London (BST/GMT)</span>
              <span className="text-2xl font-mono font-bold text-slate-800 my-1">{formatTimezone(1)}</span>
              <span className="text-[10px] text-slate-500">{formatDatezone(1)}</span>
            </div>

            {/* New York */}
            <div className="bg-slate-50 border border-slate-100 rounded-2xl p-4 flex flex-col items-center text-center shadow-sm">
              <span className="text-xs text-amber-600 font-bold tracking-wider uppercase">New York (EDT)</span>
              <span className="text-2xl font-mono font-bold text-slate-800 my-1">{formatTimezone(-4)}</span>
              <span className="text-[10px] text-slate-500">{formatDatezone(-4)}</span>
            </div>
          </div>
        </div>
      )}

      {activeWidget === 'weather' && (
        <div className="space-y-4">
          <div className="flex justify-between items-center mb-1">
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Simulasi Atmosferik Global</h4>
            <select
              value={city}
              onChange={(e) => setCity(e.target.value)}
              className="px-2.5 py-1 text-xs font-semibold rounded border border-slate-200 bg-white text-slate-700 focus:outline-none"
            >
              <option value="Jakarta">Jakarta 🇮🇩</option>
              <option value="Tangerang">Tangerang 🇮🇩</option>
              <option value="Bandung">Bandung 🇮🇩</option>
              <option value="Tokyo">Tokyo 🇯🇵</option>
              <option value="London">London 🇬🇧</option>
              <option value="StMoritz">St. Moritz 🇨🇭</option>
            </select>
          </div>

          <div className={`rounded-2xl p-6 text-white relative overflow-hidden flex flex-col items-center text-center ${
            weatherType === 'Sunny' ? 'bg-gradient-to-tr from-amber-500 to-orange-400' :
            weatherType === 'Rainy' ? 'bg-gradient-to-tr from-blue-600 to-indigo-800' :
            weatherType === 'Snowy' ? 'bg-gradient-to-tr from-sky-400 to-slate-300' :
            'bg-gradient-to-tr from-sky-600 to-slate-500'
          }`}>
            <div className="absolute right-4 top-4 opacity-15">
              {weatherType === 'Sunny' && <Sun className="w-24 h-24" />}
              {weatherType === 'Rainy' && <CloudRain className="w-24 h-24" />}
              {weatherType === 'Snowy' && <CloudSnow className="w-24 h-24" />}
            </div>

            <span className="text-sm font-bold tracking-wider uppercase">{city}</span>
            <span className="text-6xl font-bold tracking-tighter my-3 flex items-start">
              {temp}<span className="text-2xl mt-1">°C</span>
            </span>
            <span className="text-base font-semibold uppercase">{weatherType}</span>

            <div className="flex gap-4 mt-4 pt-4 border-t border-white/20 w-full justify-center">
              <div className="flex items-center gap-1.5 text-xs">
                <Wind className="w-4 h-4" />
                <span>Kecepatan Angin: {wind} km/h</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {activeWidget === 'rates' && (
        <div className="space-y-4">
          <div className="flex items-center gap-2 mb-2">
            <Landmark className="w-4 h-4 text-emerald-500" />
            <h4 className="text-xs font-bold text-slate-400 uppercase tracking-wider">Konverter Kurs (Mata Uang Acuan: USD)</h4>
          </div>

          <div className="space-y-3 bg-slate-50 border border-slate-100 rounded-2xl p-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Jumlah (USD)</label>
              <input
                type="number"
                min="1"
                value={baseAmount}
                onChange={(e) => setBaseAmount(parseFloat(e.target.value) || 0)}
                className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-800 font-semibold focus:outline-none focus:ring-1 focus:ring-emerald-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-2">
              <div>
                <label className="block text-[10px] font-bold text-slate-400 uppercase mb-1">Mata Uang Tujuan</label>
                <select
                  value={selectedRate}
                  onChange={(e) => setSelectedRate(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-200 bg-white text-slate-700 font-semibold focus:outline-none"
                >
                  {Object.keys(exchangeRates).map((r) => (
                    <option key={r} value={r}>{r}</option>
                  ))}
                </select>
              </div>

              <div className="flex flex-col justify-end">
                <span className="text-[10px] font-bold text-slate-400 uppercase mb-1">Nilai Kurs</span>
                <span className="text-sm font-mono font-bold text-slate-500 py-2">
                  1 USD = {exchangeRates[selectedRate].toLocaleString('id-ID')} {selectedRate}
                </span>
              </div>
            </div>

            <div className="pt-3 border-t border-slate-200/50">
              <span className="text-[10px] font-bold text-slate-400 uppercase">Hasil Konversi</span>
              <div className="text-xl font-bold text-emerald-600 tracking-tight mt-0.5">
                {(baseAmount * exchangeRates[selectedRate]).toLocaleString('id-ID', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {selectedRate}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
