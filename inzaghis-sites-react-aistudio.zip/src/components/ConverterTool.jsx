import React, { useState, useEffect } from 'react';
import { ArrowUpDown, RefreshCw } from 'lucide-react';

export default function ConverterTool() {
  const [type, setType] = useState('temperature');
  const [value, setValue] = useState('0');
  const [fromUnit, setFromUnit] = useState('Celsius');
  const [toUnit, setToUnit] = useState('Fahrenheit');
  const [result, setResult] = useState('');

  const temperatureUnits = ['Celsius', 'Fahrenheit', 'Kelvin', 'Reamur'];
  const massUnits = ['Kilogram', 'Gram', 'Pound', 'Ounce'];
  const lengthUnits = ['Meter', 'Kilometer', 'Centimeter', 'Mile', 'Inch'];
  const numSystemUnits = ['Decimal', 'Binary', 'Octal', 'Hexadecimal'];

  useEffect(() => {
    // Set default units when type changes
    if (type === 'temperature') {
      setFromUnit('Celsius');
      setToUnit('Fahrenheit');
      setValue('0');
    } else if (type === 'mass') {
      setFromUnit('Kilogram');
      setToUnit('Gram');
      setValue('1');
    } else if (type === 'length') {
      setFromUnit('Meter');
      setToUnit('Centimeter');
      setValue('1');
    } else if (type === 'numsystem') {
      setFromUnit('Decimal');
      setToUnit('Binary');
      setValue('10');
    }
  }, [type]);

  useEffect(() => {
    performConversion();
  }, [value, fromUnit, toUnit, type]);

  const performConversion = () => {
    const num = parseFloat(value);
    if (isNaN(num) && type !== 'numsystem') {
      setResult('');
      return;
    }

    if (type === 'temperature') {
      let celsius = num;
      // Convert to Celsius first
      if (fromUnit === 'Fahrenheit') celsius = ((num - 32) * 5) / 9;
      else if (fromUnit === 'Kelvin') celsius = num - 273.15;
      else if (fromUnit === 'Reamur') celsius = (num * 5) / 4;

      // Convert Celsius to destination
      let val = celsius;
      if (toUnit === 'Fahrenheit') val = (celsius * 9) / 5 + 32;
      else if (toUnit === 'Kelvin') val = celsius + 273.15;
      else if (toUnit === 'Reamur') val = (celsius * 4) / 5;

      setResult(val.toFixed(4).replace(/\.?0+$/, ''));
    } 
    else if (type === 'mass') {
      // Base: Grams
      let grams = num;
      if (fromUnit === 'Kilogram') grams = num * 1000;
      else if (fromUnit === 'Pound') grams = num * 453.59237;
      else if (fromUnit === 'Ounce') grams = num * 28.34952;

      let val = grams;
      if (toUnit === 'Kilogram') val = grams / 1000;
      else if (toUnit === 'Pound') val = grams / 453.59237;
      else if (toUnit === 'Ounce') val = grams / 28.34952;

      setResult(val.toFixed(4).replace(/\.?0+$/, ''));
    } 
    else if (type === 'length') {
      // Base: Meters
      let meters = num;
      if (fromUnit === 'Kilometer') meters = num * 1000;
      else if (fromUnit === 'Centimeter') meters = num / 100;
      else if (fromUnit === 'Mile') meters = num * 1609.344;
      else if (fromUnit === 'Inch') meters = num * 0.0254;

      let val = meters;
      if (toUnit === 'Kilometer') val = meters / 1000;
      else if (toUnit === 'Centimeter') val = meters * 100;
      else if (toUnit === 'Mile') val = meters / 1609.344;
      else if (toUnit === 'Inch') val = meters / 0.0254;

      setResult(val.toFixed(4).replace(/\.?0+$/, ''));
    } 
    else if (type === 'numsystem') {
      try {
        let decimal = 0;
        const cleanVal = value.trim();
        if (!cleanVal) {
          setResult('');
          return;
        }

        if (fromUnit === 'Decimal') decimal = parseInt(cleanVal, 10);
        else if (fromUnit === 'Binary') decimal = parseInt(cleanVal, 2);
        else if (fromUnit === 'Octal') decimal = parseInt(cleanVal, 8);
        else if (fromUnit === 'Hexadecimal') decimal = parseInt(cleanVal, 16);

        if (isNaN(decimal)) {
          setResult('Invalid input');
          return;
        }

        let out = '';
        if (toUnit === 'Decimal') out = decimal.toString(10);
        else if (toUnit === 'Binary') out = decimal.toString(2);
        else if (toUnit === 'Octal') out = decimal.toString(8);
        else if (toUnit === 'Hexadecimal') out = decimal.toString(16).toUpperCase();

        setResult(out);
      } catch (err) {
        setResult('Error');
      }
    }
  };

  const handleSwap = () => {
    const temp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(temp);
  };

  const getUnits = () => {
    switch (type) {
      case 'temperature': return temperatureUnits;
      case 'mass': return massUnits;
      case 'length': return lengthUnits;
      case 'numsystem': return numSystemUnits;
    }
  };

  return (
    <div id="converter-root" className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 max-w-xl mx-auto">
      <div className="flex flex-wrap gap-2 mb-6 border-b border-slate-100 pb-4">
        {['temperature', 'mass', 'length', 'numsystem'].map((t) => (
          <button
            key={t}
            id={`btn-convert-${t}`}
            onClick={() => setType(t)}
            className={`px-4 py-2 rounded-xl text-xs font-semibold uppercase tracking-wider transition-all duration-200 ${
              type === t
                ? 'bg-emerald-500 text-white shadow-sm'
                : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            {t === 'numsystem' ? 'Bilangan' : t.charAt(0).toUpperCase() + t.slice(1)}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-xs font-medium text-slate-500 mb-1.5 uppercase">Input Value</label>
          <input
            id="converter-input-val"
            type={type === 'numsystem' ? 'text' : 'number'}
            value={value}
            onChange={(e) => setValue(e.target.value)}
            className="w-full px-4 py-3 rounded-xl border border-slate-200 text-slate-800 font-medium focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
            placeholder="Masukkan nilai..."
          />
        </div>

        <div className="grid grid-cols-1 md:grid-cols-9 gap-2 items-center">
          <div className="md:col-span-4">
            <label className="block text-xs font-medium text-slate-500 mb-1.5 uppercase">From</label>
            <select
              id="converter-from-select"
              value={fromUnit}
              onChange={(e) => setFromUnit(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            >
              {getUnits().map((u) => (
                <option key={u} value={u}>{u}</option>
              ))}
            </select>
          </div>

          <div className="md:col-span-1 flex justify-center pt-5">
            <button
              id="converter-swap-btn"
              onClick={handleSwap}
              className="p-2.5 rounded-full bg-slate-50 hover:bg-slate-100 text-slate-500 transition-colors border border-slate-200 shadow-sm"
              title="Swap Units"
            >
              <ArrowUpDown className="w-4 h-4" />
            </button>
          </div>

          <div className="md:col-span-4">
            <label className="block text-xs font-medium text-slate-500 mb-1.5 uppercase">To</label>
            <select
              id="converter-to-select"
              value={toUnit}
              onChange={(e) => setToUnit(e.target.value)}
              className="w-full px-3 py-2.5 rounded-xl border border-slate-200 text-slate-700 bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500/20"
            >
              {getUnits().map((u) => (
                <option key={u} value={u}>{u}</option>
              ))}
            </select>
          </div>
        </div>

        <div className="bg-slate-50 rounded-xl p-4 border border-slate-100 mt-6">
          <label className="block text-xs font-medium text-slate-400 mb-1 uppercase">Hasil Konversi</label>
          <div id="converter-result-display" className="text-2xl font-bold text-emerald-600 tracking-tight break-all">
            {result !== '' ? `${result} ${type !== 'numsystem' ? toUnit : ''}` : '---'}
          </div>
        </div>
      </div>
    </div>
  );
}
