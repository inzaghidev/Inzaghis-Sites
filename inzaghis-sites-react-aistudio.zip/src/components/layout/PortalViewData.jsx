"use client";

import { motion } from "framer-motion";
import { useParams, useNavigate } from "react-router-dom";
import WidgetPortal from "../WidgetPortal";
import TutorialPortal from "../TutorialPortal";
import { BookOpen, Laptop, ExternalLink } from "lucide-react";

export default function PortalViewData({
  portalsList,
  showToast,
}) {
  const { portalId } = useParams();
  const navigate = useNavigate();

  return (
    <motion.section
      key="portals-view"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      id="portals-view-container"
      className="space-y-8"
    >
      {/* Header block */}
      <div className="text-left space-y-2">
        <h2 className="text-3xl font-black font-display text-slate-900 tracking-tight flex items-center gap-2">
          Portals{" "}
          <span className="text-[10px] bg-sky-100 text-sky-700 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
            Beta
          </span>
        </h2>
        <p className="text-xs md:text-sm text-slate-500 max-w-3xl leading-relaxed font-normal">
          Portals merupakan Halaman Portal yang tersedia untuk berbagai
          kebutuhan apapun seperti Widgets, Tutorial Teknologi, Materi
          Pembelajaran, dan lainnya.
        </p>
      </div>

      {/* If a sub portal is selected, show it focused */}
      {portalId ? (
        <div className="bg-white border border-slate-200/60 rounded-3xl p-6 md:p-8 shadow-sm">
          <div className="flex items-center justify-between mb-6 border-b border-slate-100 pb-4">
            <button
              onClick={() => navigate("/portals")}
              className="px-4 py-1.5 border border-slate-200 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-all uppercase"
            >
              ← Kembali ke Semua Portal
            </button>
            <span className="text-xs font-bold text-emerald-600 uppercase tracking-wide">
              Portal Terpilih
            </span>
          </div>

          {portalId === "widgets" && <WidgetPortal />}
          {portalId === "tutorials" && <TutorialPortal />}
          {portalId === "materials" && (
            <div className="max-w-xl mx-auto space-y-4 bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center">
              <BookOpen className="w-10 h-10 text-blue-500 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">
                Learning Materials & Thesis Repo
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto">
                Akses modul kuliah TI, draf tugas akhir, panduan instalasi Linux
                server, serta hasil wawancara riset AI secara gratis.
              </p>
              <button
                onClick={() =>
                  showToast("Mengunduh katalog modul pembelajaran terbaru...")
                }
                className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded-xl text-xs font-bold transition-all uppercase"
              >
                Unduh Katalog (PDF)
              </button>
            </div>
          )}
          {portalId === "projects" && (
            <div className="max-w-xl mx-auto space-y-4 bg-slate-50 border border-slate-100 rounded-2xl p-6 text-center">
              <Laptop className="w-10 h-10 text-emerald-500 mx-auto" />
              <h3 className="text-base font-bold text-slate-800">
                Inzaghi's Projects Showcase
              </h3>
              <p className="text-xs text-slate-500 leading-relaxed max-w-sm mx-auto">
                Lihat daftar lengkap repositori GitHub yang diproduksi oleh tim
                InzaTech, dari microservices hingga sensor IoT cerdas.
              </p>
              <a
                href="https://github.com/inzaghidev"
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-1.5 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white rounded-xl text-xs font-bold transition-all uppercase"
              >
                Buka GitHub Inzaghi <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          )}
        </div>
      ) : (
        /* Grid of all Portals */
        <div
          id="portals-grid"
          className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2"
        >
          {portalsList.map((portal) => (
            <div
              key={portal.id}
              className="bg-white border border-slate-200/70 rounded-3xl overflow-hidden flex flex-col md:flex-row shadow-sm hover:shadow-md transition-shadow"
            >
              {/* Left Graphic Side */}
              <div
                className={`md:w-2/5 p-6 flex flex-col items-center justify-between text-center ${
                  portal.id === "tutorials"
                    ? "bg-[#0f1d1f] text-white"
                    : "bg-[#fbeaea]"
                }`}
              >
                <div>
                  <span
                    className={`text-[10px] font-extrabold uppercase tracking-widest ${
                      portal.id === "tutorials"
                        ? "text-teal-400"
                        : "text-rose-500"
                    }`}
                  >
                    {portal.category}
                  </span>
                </div>

                {portal.id === "widgets" && (
                  <div className="my-6 space-y-3 flex flex-col items-center">
                    <span className="font-display font-black text-lg text-slate-900 tracking-wider">
                      WIDGETS
                    </span>
                    <div className="grid grid-cols-2 gap-2">
                      <div className="w-5 h-5 bg-rose-500 rounded"></div>
                      <div className="w-5 h-5 bg-rose-500 rotate-45 rounded"></div>
                      <div className="w-5 h-5 bg-rose-500 rounded"></div>
                      <div className="w-5 h-5 bg-rose-500 rounded"></div>
                    </div>
                    <span className="text-[10px] font-bold text-slate-500">
                      Portals
                    </span>
                  </div>
                )}

                {portal.id === "tutorials" && (
                  <div className="my-6 space-y-3 flex flex-col items-center">
                    <span className="font-display font-black text-base text-white tracking-wider">
                      TECH TUTORIALS
                    </span>
                    <svg
                      className="w-12 h-12 text-teal-400"
                      viewBox="0 0 24 24"
                      fill="none"
                      stroke="currentColor"
                      strokeWidth="2"
                    >
                      <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
                      <line x1="8" y1="21" x2="16" y2="21" />
                      <line x1="12" y1="17" x2="12" y2="21" />
                      <path d="M10 8l-2 2 2 2M14 8l2 2-2 2" />
                    </svg>
                    <span className="text-[10px] font-bold text-teal-400/80">
                      Portals
                    </span>
                  </div>
                )}

                {portal.id !== "widgets" && portal.id !== "tutorials" && (
                  <div className="my-6 flex flex-col items-center gap-2">
                    <span className="font-display font-black text-base text-rose-900 tracking-wider">
                      {portal.title.toUpperCase()}
                    </span>
                    <BookOpen className="w-10 h-10 text-rose-500" />
                  </div>
                )}

                <div className="flex items-center gap-1">
                  <svg
                    className="w-4 h-4 text-emerald-500"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                  >
                    <path
                      d="M12 2L3 7v6c0 5.5 4.5 10 9 11 4.5-1 9-5.5 9-11V7l-9-5z"
                      fill="none"
                      stroke="#10b981"
                    />
                  </svg>
                  <span className="text-[9px] font-extrabold text-slate-700">
                    Inzaghi's Sites
                  </span>
                </div>
              </div>

              {/* Right Details Side */}
              <div className="md:w-3/5 p-6 md:p-8 flex flex-col justify-between text-left">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-slate-800 tracking-tight">
                    {portal.title}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-normal">
                    {portal.description}
                  </p>
                </div>

                <div className="pt-6">
                  <button
                    onClick={() => navigate(`/portals/${portal.id}`)}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-colors shadow-sm"
                  >
                    Click here
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.section>
  );
}
