"use client";

import { motion } from "framer-motion";
import { useParams, useNavigate } from "react-router-dom";
import ConverterTool from "../ConverterTool";
import CalculatorTool from "../CalculatorTool";
import GeneratorTool from "../GeneratorTool";
import FormatterTool from "../FormatterTool";

export default function AppViewData({ appsList }) {
  const { appId } = useParams();
  const navigate = useNavigate();

  return (
    <motion.section
      key="apps-view"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      id="apps-view-container"
      className="space-y-8"
    >
      {/* Header block */}
      <div className="text-left space-y-2">
        <h2 className="text-3xl font-black font-display text-slate-900 tracking-tight flex items-center gap-2">
          Pages Apps{" "}
          <span className="text-[10px] bg-amber-100 text-amber-700 px-2 py-0.5 rounded-full font-bold uppercase tracking-wider">
            Beta
          </span>
        </h2>
        <p className="text-xs md:text-sm text-slate-500 max-w-3xl leading-relaxed font-normal">
          Pages Apps merupakan Halaman Aplikasi yang tersedia untuk berbagai
          kebutuhan. Pages Apps menyediakan berbagai Portal seperti Kalkulator,
          Generator, Formatter, dan lainnya.
        </p>
      </div>

      {/* Focused Active Tool Area */}
      {appId ? (
        <div className="bg-white border border-slate-200/60 rounded-3xl p-6 md:p-8 shadow-sm">
          <div className="flex items-center justify-between mb-6 border-b border-slate-100 pb-4">
            <button
              onClick={() => navigate("/apps")}
              className="px-4 py-1.5 border border-slate-200 rounded-xl text-xs font-semibold text-slate-600 hover:bg-slate-50 transition-all uppercase"
            >
              ← Kembali ke Semua Apps
            </button>
            <span className="text-xs font-bold text-emerald-600 uppercase tracking-wide">
              Aplikasi Terpilih: {appId.toUpperCase()}
            </span>
          </div>

          {appId === "converters" && <ConverterTool />}
          {appId === "calculators" && <CalculatorTool />}
          {appId === "generators" && <GeneratorTool />}
          {appId === "formatters" && <FormatterTool />}
        </div>
      ) : (
        /* Grid of all Apps */
        <div
          id="apps-grid"
          className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-2"
        >
          {appsList.map((app) => (
            <div
              key={app.id}
              className="bg-white border border-slate-200/60 rounded-3xl overflow-hidden flex flex-col md:flex-row shadow-sm hover:shadow-md transition-shadow"
            >
              {/* Left side category card */}
              <div
                className={`md:w-2/5 p-6 flex flex-col items-center justify-between text-center ${
                  app.id === "converters"
                    ? "bg-rose-50"
                    : app.id === "calculators"
                      ? "bg-amber-50"
                      : app.id === "generators"
                        ? "bg-sky-50"
                        : "bg-violet-50"
                }`}
              >
                <div>
                  <span
                    className={`text-[9px] font-black uppercase tracking-widest ${
                      app.id === "converters"
                        ? "text-pink-600"
                        : app.id === "calculators"
                          ? "text-amber-700"
                          : app.id === "generators"
                            ? "text-sky-600"
                            : "text-violet-600"
                    }`}
                  >
                    {app.title.toUpperCase()}
                  </span>
                </div>

                {/* App icon container */}
                <div className="my-5 flex flex-col items-center gap-2">
                  {app.id === "converters" && (
                    <svg
                      className="w-12 h-12 text-pink-500 animate-pulse"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M12 6v12m-3-2.818l.251.11a3.375 3.375 0 003.498-.112l.147-.091a3.375 3.375 0 001.37-2.733c0-1.867-1.425-3.375-3.187-3.375-1.762 0-3.188-1.508-3.188-3.375 0-1.868 1.426-3.375 3.188-3.375 1.762 0 3.187 1.507 3.187 3.375M21 12a9 9 0 11-18 0 9 9 0 0118 0z"
                      />
                    </svg>
                  )}
                  {app.id === "calculators" && (
                    <svg
                      className="w-12 h-12 text-amber-500"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    >
                      <rect
                        x="4"
                        y="2"
                        width="16"
                        height="20"
                        rx="2"
                        strokeWidth="2"
                      />
                      <rect x="7" y="5" width="10" height="4" rx="1" />
                      <circle cx="8" cy="13" r="1" />
                      <circle cx="12" cy="13" r="1" />
                      <circle cx="16" cy="13" r="1" />
                      <circle cx="8" cy="17" r="1" />
                      <circle cx="12" cy="17" r="1" />
                      <circle cx="16" cy="17" r="1" />
                    </svg>
                  )}
                  {app.id === "generators" && (
                    <svg
                      className="w-12 h-12 text-sky-500 animate-spin"
                      style={{ animationDuration: "12s" }}
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M4.5 12a7.5 7.5 0 0015 0m-15 0a7.5 7.5 0 1115 0m-15 0H3m16.5 0H21m-1.5 0H12m-8.457 3.077l1.41-.513m14.095-5.13l1.41-.513M5.106 17.785l1.15-.827m11.379-8.16l1.15-.827M8.14 21.27l.707-1.03m7.56-11.01l.707-1.03M12 3v1.5m0 15V21m-3.077-16.5l.513 1.41m5.13 14.095l.513 1.41M4.215 6.225l.827 1.15m8.16 11.379l.827 1.15M2.73 8.14l1.03.707m11.01 7.56l1.03.707"
                      />
                    </svg>
                  )}
                  {app.id === "formatters" && (
                    <svg
                      className="w-12 h-12 text-violet-500"
                      fill="none"
                      viewBox="0 0 24 24"
                      stroke="currentColor"
                      strokeWidth="1.5"
                    >
                      <path
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z"
                      />
                    </svg>
                  )}
                  <span className="text-[10px] text-slate-400 font-bold tracking-tight">
                    Pages Apps
                  </span>
                </div>

                {/* logo footer of left side */}
                <div className="flex items-center gap-1">
                  <svg
                    className="w-3.5 h-3.5 text-emerald-500"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.5"
                  >
                    <path
                      d="M12 2L3 7v6c0 5.5 4.5 10 9 11 4.5-1 9-5.5 9-11V7l-9-5z"
                      fill="none"
                      stroke="#10b981"
                    />
                  </svg>
                  <span className="text-[8px] font-extrabold text-slate-500">
                    Inzaghi's Sites
                  </span>
                </div>
              </div>

              {/* Right details content side */}
              <div className="md:w-3/5 p-6 md:p-8 flex flex-col justify-between text-left">
                <div className="space-y-2">
                  <h3 className="text-xl font-bold text-slate-800 tracking-tight">
                    {app.title}
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-normal">
                    {app.description}
                  </p>
                </div>

                <div className="pt-6">
                  <button
                    onClick={() => navigate(`/apps/${app.id}`)}
                    className="px-5 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-colors shadow-sm"
                  >
                    Click here
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </motion.section>
  );
}
