import React from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { ChevronDown, Menu, X, FileText, User, Shield } from "lucide-react";
import { portalsList, appsList } from "../../data";

export default function Navbar({
  activeDropdown,
  setActiveDropdown,
  mobileMenuOpen,
  setMobileMenuOpen,
  toggleMobileDropdown,
  mobileDropdowns,
  user,
  handleLogout,
  showToast,
  handleDropdownClick,
  setLegalModal,
}) {
  const location = useLocation();
  const navigate = useNavigate();

  const goHome = () => {
    navigate("/");
  };

  const closeMenus = () => {
    setActiveDropdown(null);
    setMobileMenuOpen(false);
  };

  const handleDropdownSelect = (view, subId = null) => {
    setActiveDropdown(null);
    setMobileMenuOpen(false);
    if (subId) {
      navigate(`/${view}/${subId}`);
    } else {
      navigate(`/${view}`);
    }
  };

  return (
    <>
      <header
        id="main-header"
        className="sticky top-0 z-40 bg-white/70 backdrop-blur-xl border-b border-slate-200/60 transition-all duration-300"
      >
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          <div
            id="header-logo isites-logo"
            className="flex items-center gap-2.5 cursor-pointer"
            onClick={goHome}
          >
            <img
              src="/icons/inzaghis-sites-logo-vertical-transparent.png"
              title="Inzaghi's Sites"
              className="!h-14"
              id="logo-nav"
              alt="Inzaghi's Sites"
            />
          </div>

          <nav id="desktop-nav" className="hidden lg:flex items-center gap-1">
            <Link
              id="nav-link-home"
              to="/"
              onClick={closeMenus}
              className={`px-3 py-2 rounded-xl text-[13px] font-semibold tracking-wide transition-all ${
                location.pathname === "/"
                  ? "text-emerald-600 bg-[#cfefdf]"
                  : "text-slate-600 hover:text-slate-900 hover:bg-[#c1e0d1]"
              }`}
            >
              Home
            </Link>

            <div className="relative">
              <button
                id="nav-dropdown-blogs"
                onClick={() => handleDropdownClick("blogs")}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-[13px] font-semibold text-slate-600 hover:text-slate-900 hover:bg-[#c1e0d1] transition-all"
              >
                Blogs{" "}
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === "blogs" ? "rotate-180" : ""}`}
                />
              </button>
              {activeDropdown === "blogs" && (
                <div className="absolute left-0 mt-2 w-48 bg-white border border-slate-200 rounded-2xl shadow-xl py-2 z-50">
                  <Link
                    to="/blogs"
                    onClick={closeMenus}
                    className="w-full text-left px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 hover:text-blue-800 transition-colors flex items-center justify-between"
                  >
                    Inzaghi's Blog{" "}
                    <span className="text-[10px] bg-emerald-50 text-emerald-600 px-1.5 py-0.5 rounded-full font-bold">
                      New
                    </span>
                  </Link>
                  <Link
                    to="/blogs"
                    onClick={closeMenus}
                    className="w-full text-left px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 hover:text-blue-800 transition-colors"
                  >
                    Inzaghi's Media
                  </Link>
                </div>
              )}
            </div>

            <div className="relative">
              <button
                id="nav-dropdown-portals"
                onClick={() => handleDropdownClick("portals")}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-[13px] font-semibold text-slate-600 hover:text-slate-900 hover:bg-[#c1e0d1] transition-all"
              >
                Portals{" "}
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === "portals" ? "rotate-180" : ""}`}
                />
              </button>
              {activeDropdown === "portals" && (
                <div className="absolute left-0 mt-2 w-52 bg-white border border-slate-200 rounded-2xl shadow-xl py-2 z-50">
                  {portalsList.map((p) => (
                    <Link
                      key={p.id}
                      to={`/portals/${p.id}`}
                      onClick={closeMenus}
                      className="block w-full text-left px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 hover:text-blue-800 transition-colors"
                    >
                      {p.title}
                    </Link>
                  ))}
                  <div className="border-t border-slate-100 my-1"></div>
                  <Link
                    to="/portals"
                    onClick={closeMenus}
                    className="block w-full text-left px-4 py-2.5 text-xs font-bold text-emerald-600 hover:bg-slate-50 hover:text-blue-800 transition-colors"
                  >
                    Semua Portal
                  </Link>
                </div>
              )}
            </div>

            <div className="relative">
              <button
                id="nav-dropdown-apps"
                onClick={() => handleDropdownClick("apps")}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-[13px] font-semibold text-slate-600 hover:text-slate-900 hover:bg-[#c1e0d1] transition-all"
              >
                Apps{" "}
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === "apps" ? "rotate-180" : ""}`}
                />
              </button>
              {activeDropdown === "apps" && (
                <div className="absolute left-0 mt-2 w-52 bg-white border border-slate-200 rounded-2xl shadow-xl py-2 z-50">
                  {appsList.map((a) => (
                    <Link
                      key={a.id}
                      to={`/apps/${a.id}`}
                      onClick={closeMenus}
                      className="block w-full text-left px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-slate-50 hover:text-blue-800 transition-colors"
                    >
                      {a.title}
                    </Link>
                  ))}
                  <div className="border-t border-slate-100 my-1"></div>
                  <Link
                    to="/apps"
                    onClick={closeMenus}
                    className="block w-full text-left px-4 py-2.5 text-xs font-bold text-emerald-600 hover:bg-slate-50 hover:text-blue-800 transition-colors"
                  >
                    Semua Aplikasi
                  </Link>
                </div>
              )}
            </div>

            <Link
              id="nav-link-contact"
              to="/contact"
              onClick={closeMenus}
              className={`px-3 py-2 rounded-xl text-[13px] font-semibold tracking-wide transition-all ${
                location.pathname === "/contact"
                  ? "text-emerald-600 bg-[#cfefdf]"
                  : "text-slate-600 hover:text-slate-900 hover:bg-[#c1e0d1]"
              }`}
            >
              Contact
            </Link>

            <div className="relative">
              <button
                id="nav-dropdown-about"
                onClick={() => handleDropdownClick("about")}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-[13px] font-semibold text-slate-600 hover:text-slate-900 hover:bg-[#c1e0d1] transition-all"
              >
                About & Profile{" "}
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === "about" ? "rotate-180" : ""}`}
                />
              </button>
              {activeDropdown === "about" && (
                <div className="absolute right-0 mt-2 w-52 bg-white border border-slate-200 rounded-2xl shadow-xl py-2 z-50">
                  <button
                    onClick={() => {
                      navigate("/about");
                      setActiveDropdown(null);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-[#c1e0d1] flex items-center gap-2"
                  >
                    <User className="w-4 h-4 text-slate-400" /> Profil
                    Pengembang
                  </button>
                  <button
                    onClick={() => {
                      setLegalModal("disclaimer");
                      setActiveDropdown(null);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-[#c1e0d1] flex items-center gap-2"
                  >
                    <Shield className="w-4 h-4 text-slate-400" /> Disclaimer
                  </button>
                  <button
                    onClick={() => {
                      setLegalModal("privacy");
                      setActiveDropdown(null);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-[#c1e0d1] flex items-center gap-2"
                  >
                    <FileText className="w-4 h-4 text-slate-400" /> Privacy
                    Policy
                  </button>
                </div>
              )}
            </div>

            <div className="relative">
              <button
                id="nav-dropdown-group"
                onClick={() => handleDropdownClick("group")}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-[13px] font-semibold text-slate-600 hover:text-slate-900 hover:bg-[#c1e0d1] transition-all"
              >
                Inzaghi's Group{" "}
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === "group" ? "rotate-180" : ""}`}
                />
              </button>
              {activeDropdown === "group" && (
                <div className="absolute right-0 mt-2 w-48 bg-white border border-slate-200 rounded-2xl shadow-xl py-2 z-50">
                  <a
                    href="https://github.com/inzaghidev"
                    target="_blank"
                    rel="noreferrer"
                    className="block px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-[#c1e0d1]"
                  >
                    InzaTech Corp
                  </a>
                  <a
                    href="https://github.com/inzaghidev/Inzaghis-Sites"
                    target="_blank"
                    rel="noreferrer"
                    className="block px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-[#c1e0d1]"
                  >
                    Poshaf Media Group
                  </a>
                </div>
              )}
            </div>

            <div className="relative">
              <button
                id="nav-dropdown-switch"
                onClick={() => handleDropdownClick("switch")}
                className="flex items-center gap-1 px-3 py-2 rounded-xl text-[13px] font-semibold text-slate-600 hover:text-slate-900 hover:bg-[#c1e0d1] transition-all"
              >
                Switch to{" "}
                <ChevronDown
                  className={`w-3.5 h-3.5 transition-transform duration-200 ${activeDropdown === "switch" ? "rotate-180" : ""}`}
                />
              </button>
              {activeDropdown === "switch" && (
                <div className="absolute right-0 mt-2 w-52 bg-white border border-slate-200 rounded-2xl shadow-xl py-2 z-50">
                  <button
                    onClick={() => {
                      showToast(
                        "Anda sudah menggunakan UI Baru v4 yang super mulus!",
                      );
                      setActiveDropdown(null);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-[#c1e0d1]"
                  >
                    Old UI (Branch: new)
                  </button>
                  <button
                    onClick={() => {
                      showToast("Bahasa diubah ke Indonesia 🇮🇩");
                      setActiveDropdown(null);
                    }}
                    className="w-full text-left px-4 py-2.5 text-xs font-semibold text-slate-700 hover:bg-[#c1e0d1]"
                  >
                    Bahasa Indonesia (Utama)
                  </button>
                </div>
              )}
            </div>
          </nav>

          <div className="hidden lg:flex items-center gap-3">
            {user ? (
              <div className="flex items-center gap-3">
                <span className="text-xs font-semibold text-slate-600">
                  Halo,{" "}
                  <span className="text-emerald-600 font-bold">
                    {user.name}
                  </span>
                </span>
                <button
                  id="btn-logout"
                  onClick={handleLogout}
                  className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all"
                >
                  Logout
                </button>
              </div>
            ) : (
              <button
                id="btn-sign-in"
                onClick={() => navigate("/signin")}
                className="relative px-6 py-2.5 bg-slate-950 text-white font-bold text-[13px] rounded-xl hover:bg-slate-900 transition-all shadow-[0_0_12px_rgba(30,41,59,0.15)] border border-slate-800"
              >
                Sign in
              </button>
            )}
          </div>

          <div className="flex lg:hidden items-center gap-2">
            {user ? (
              <div className="hidden sm:flex items-center gap-2.5 mr-1">
                <span className="text-xs font-semibold text-slate-600">
                  Halo,{" "}
                  <span className="text-emerald-600 font-bold">
                    {user.name}
                  </span>
                </span>
                <button
                  onClick={handleLogout}
                  className="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all"
                >
                  Logout
                </button>
              </div>
            ) : (
              <button
                onClick={() => navigate("/signin")}
                className="sign-in-button sm:block relative inline-flex items-center justify-center p-0.5 mb-1 mr-1.5 overflow-hidden text-xs font-semibold text-white rounded-lg group bg-linear-to-br from-green-400 to-blue-600 group-hover:from-green-400 group-hover:to-blue-600 hover:text-white focus:ring-4 focus:outline-none focus:ring-green-200 transition-all cursor-pointer"
              >
                <span className="main-button-nav relative px-4 py-2 transition-all ease-in duration-75 bg-gray-900 rounded-md group-hover:bg-opacity-0 block text-xs">
                  Sign in
                </span>
              </button>
            )}

            <div className="menu-toggle flex items-center hover:bg-slate-100 rounded-lg transition-all">
              <button
                onClick={() => setMobileMenuOpen(true)}
                className="mobile-menu-button py-2 px-2"
                aria-label="Toggle Menu"
              >
                <svg
                  xmlns="http://www.w3.org/2000/svg"
                  width="24"
                  height="24"
                  viewBox="0 0 24 24"
                  className="text-slate-800"
                >
                  <title>Menu Toggle</title>
                  <g
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                  >
                    <path d="M3.75 6.75h16.5M3.75 12h16.5M3.75 17.25h16.5" />
                  </g>
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Sliding Sidebar Drawer & Overlay */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <>
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={() => setMobileMenuOpen(false)}
              className="fixed inset-0 bg-slate-900/50 backdrop-blur-sm z-50 lg:hidden"
            />

            <motion.div
              initial={{ x: "-100%" }}
              animate={{ x: 0 }}
              exit={{ x: "-100%" }}
              transition={{ type: "spring", damping: 26, stiffness: 220 }}
              id="mobile-sidebar-drawer"
              className="fixed inset-y-0 left-0 w-80 max-w-full bg-white shadow-2xl z-50 flex flex-col lg:hidden border-r border-slate-100 overflow-hidden text-left"
            >
              <div className="flex items-center justify-between px-5 py-4 bg-slate-50 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <img
                    src="/icons/inzaghis-sites-logo-vertical-transparent.png"
                    title="Inzaghi's Sites"
                    className="!h-14"
                    id="logo-nav"
                    alt="Inzaghi's Sites"
                  />
                </div>

                <button
                  onClick={() => setMobileMenuOpen(false)}
                  className="p-2.5 rounded-lg hover:bg-slate-200/60 text-slate-500 hover:text-slate-900 transition-all"
                  aria-label="Close Menu"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>

              <div className="flex-1 overflow-y-auto px-4 py-4 space-y-1.5 font-sans text-sm">
                <Link
                  to="/"
                  onClick={closeMenus}
                  className={`w-full block text-left py-3 px-4 rounded-lg font-semibold transition-colors ${
                    location.pathname === "/" && !activeDropdown
                      ? "bg-[#c1e0d1] text-slate-900"
                      : "text-slate-800 hover:bg-[#c1e0d1]/40 hover:text-blue-800"
                  }`}
                >
                  Home
                </Link>

                <div className="relative pt-1">
                  <button
                    onClick={() => toggleMobileDropdown("blogs")}
                    className={`w-full flex items-center justify-between py-3 px-4 rounded-lg text-slate-900 hover:bg-[#c1e0d1] transition-all font-semibold ${
                      mobileDropdowns.blogs ? "bg-[#c1e0d1]" : ""
                    }`}
                  >
                    <span>Blogs</span>
                    <span
                      className={`relative py-1 px-1 inline-flex items-center rounded-md transition-all ${
                        mobileDropdowns.blogs
                          ? "border border-gray-200 bg-[#daede4] text-gray-800 rotate-180"
                          : ""
                      }`}
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </span>
                  </button>
                  <AnimatePresence>
                    {mobileDropdowns.blogs && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden mt-1.5 rounded-xl bg-[#dadeda] p-2 space-y-0.5 shadow-inner"
                      >
                        <Link
                          to="/blogs"
                          onClick={closeMenus}
                          className="w-full block px-4 py-2.5 text-xs font-semibold text-slate-700 bg-transparent hover:text-blue-800 hover:bg-white rounded-lg transition-colors text-left"
                        >
                          Inzaghi's Blog
                        </Link>
                        <Link
                          to="/blogs"
                          onClick={closeMenus}
                          className="w-full block px-4 py-2.5 text-xs font-semibold text-slate-700 bg-transparent hover:text-blue-800 hover:bg-white rounded-lg transition-colors text-left"
                        >
                          Inzaghi's Media
                        </Link>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="relative pt-1">
                  <button
                    onClick={() => toggleMobileDropdown("portals")}
                    className={`w-full flex items-center justify-between py-3 px-4 rounded-lg text-slate-900 hover:bg-[#c1e0d1] transition-all font-semibold ${
                      mobileDropdowns.portals ? "bg-[#c1e0d1]" : ""
                    }`}
                  >
                    <span>Portals</span>
                    <span
                      className={`relative py-1 px-1 inline-flex items-center rounded-md transition-all ${
                        mobileDropdowns.portals
                          ? "border border-gray-200 bg-[#daede4] text-gray-800 rotate-180"
                          : ""
                      }`}
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </span>
                  </button>
                  <AnimatePresence>
                    {mobileDropdowns.portals && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden mt-1.5 rounded-xl bg-[#dadeda] p-2 space-y-0.5 shadow-inner max-h-65 overflow-y-auto"
                      >
                        {portalsList.map((p) => (
                          <Link
                            key={p.id}
                            to={`/portals/${p.id}`}
                            onClick={closeMenus}
                            className="w-full block px-4 py-2.5 text-xs font-semibold text-slate-700 bg-transparent hover:text-blue-800 hover:bg-white rounded-lg transition-colors text-left"
                          >
                            {p.title}
                          </Link>
                        ))}
                        <div className="border-t border-slate-100 my-1"></div>
                        <Link
                          to="/portals"
                          onClick={closeMenus}
                          className="w-full block px-4 py-2.5 text-xs font-bold text-emerald-600 hover:bg-slate-50 hover:text-blue-800 rounded-lg transition-colors text-left"
                        >
                          Semua Portal
                        </Link>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <div className="relative pt-1">
                  <button
                    onClick={() => toggleMobileDropdown("apps")}
                    className={`w-full flex items-center justify-between py-3 px-4 rounded-lg text-slate-900 hover:bg-[#c1e0d1] transition-all font-semibold ${
                      mobileDropdowns.apps ? "bg-[#c1e0d1]" : ""
                    }`}
                  >
                    <span>Apps</span>
                    <span
                      className={`relative py-1 px-1 inline-flex items-center rounded-md transition-all ${
                        mobileDropdowns.apps
                          ? "border border-gray-200 bg-[#daede4] text-gray-800 rotate-180"
                          : ""
                      }`}
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </span>
                  </button>
                  <AnimatePresence>
                    {mobileDropdowns.apps && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden mt-1.5 rounded-xl bg-[#dadeda] p-2 space-y-0.5 shadow-inner max-h-65 overflow-y-auto"
                      >
                        {appsList.map((a) => (
                          <Link
                            key={a.id}
                            to={`/apps/${a.id}`}
                            onClick={closeMenus}
                            className="w-full block px-4 py-2.5 text-xs font-semibold text-slate-700 bg-transparent hover:text-blue-800 hover:bg-white rounded-lg transition-colors text-left"
                          >
                            {a.title}
                          </Link>
                        ))}
                        <div className="border-t border-slate-100 my-1"></div>
                        <Link
                          to="/apps"
                          onClick={closeMenus}
                          className="w-full block px-4 py-2.5 text-xs font-bold text-emerald-600 hover:bg-slate-50 hover:text-blue-800 rounded-lg transition-colors text-left"
                        >
                          Semua Aplikasi
                        </Link>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>

                <Link
                  to="/contact"
                  onClick={closeMenus}
                  className={`w-full block text-left py-3 px-4 rounded-lg font-semibold transition-colors ${
                    location.pathname === "/contact"
                      ? "bg-[#c1e0d1] text-slate-900"
                      : "text-slate-800 hover:bg-[#c1e0d1]/40 hover:text-blue-800"
                  }`}
                >
                  Contact
                </Link>

                <div className="relative pt-1">
                  <button
                    onClick={() => toggleMobileDropdown("about")}
                    className={`w-full flex items-center justify-between py-3 px-4 rounded-lg text-slate-900 hover:bg-[#c1e0d1] transition-all font-semibold ${
                      mobileDropdowns.about ? "bg-[#c1e0d1]" : ""
                    }`}
                  >
                    <span>About & Profile</span>
                    <span
                      className={`relative py-1 px-1 inline-flex items-center rounded-md transition-all ${
                        mobileDropdowns.about
                          ? "border border-gray-200 bg-[#daede4] text-gray-800 rotate-180"
                          : ""
                      }`}
                    >
                      <ChevronDown className="w-3.5 h-3.5" />
                    </span>
                  </button>
                  <AnimatePresence>
                    {mobileDropdowns.about && (
                      <motion.div
                        initial={{ opacity: 0, height: 0 }}
                        animate={{ opacity: 1, height: "auto" }}
                        exit={{ opacity: 0, height: 0 }}
                        className="overflow-hidden mt-1.5 rounded-xl bg-[#dadeda] p-2 space-y-0.5 shadow-inner"
                      >
                        <button
                          onClick={() => {
                            navigate("/about");
                            setMobileMenuOpen(false);
                          }}
                          className="w-full block px-4 py-2.5 text-xs font-semibold text-slate-700 bg-transparent hover:text-gray-900 hover:bg-white rounded-lg transition-colors text-left"
                        >
                          About
                        </button>
                        <button
                          onClick={() => {
                            navigate("/profile");
                            setMobileMenuOpen(false);
                          }}
                          className="w-full block px-4 py-2.5 text-xs font-semibold text-slate-700 bg-transparent hover:text-gray-900 hover:bg-white rounded-lg transition-colors text-left"
                        >
                          Profile
                        </button>
                      </motion.div>
                    )}
                  </AnimatePresence>
                </div>
              </div>

              <div className="p-5 bg-slate-50 border-t border-slate-100 flex flex-col gap-2.5">
                {user ? (
                  <div className="space-y-2 text-center">
                    <p className="text-xs text-slate-500 font-medium">
                      Halo,{" "}
                      <span className="font-bold text-emerald-600">
                        {user.name}
                      </span>
                    </p>
                    <button
                      onClick={() => {
                        handleLogout();
                        setMobileMenuOpen(false);
                      }}
                      className="w-full py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl transition-all"
                    >
                      Logout
                    </button>
                  </div>
                ) : (
                  <button
                    onClick={() => {
                      navigate("/signin");
                      setMobileMenuOpen(false);
                    }}
                    className="w-full py-3 bg-[#10b981] hover:bg-[#059669] text-white font-extrabold text-xs rounded-xl text-center shadow-sm uppercase tracking-wider cursor-pointer"
                  >
                    Sign In
                  </button>
                )}
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
