import React, { useState } from 'react';
import { Copy, Check, ShieldCheck, Shuffle } from 'lucide-react';

export default function GeneratorTool() {
  const [activeTab, setActiveTab] = useState('password');
  
  // Password state
  const [length, setLength] = useState(16);
  const [useUpper, setUseUpper] = useState(true);
  const [useLower, setUseLower] = useState(true);
  const [useNumbers, setUseNumbers] = useState(true);
  const [useSymbols, setUseSymbols] = useState(true);
  const [password, setPassword] = useState('');
  const [pwStrength, setPwStrength] = useState('');
  
  // UUID state
  const [uuidList, setUuidList] = useState([]);
  const [uuidCount, setUuidCount] = useState(3);

  // Lorem state
  const [loremParagraphs, setLoremParagraphs] = useState([]);
  const [paragraphsCount, setParagraphsCount] = useState(2);

  // General state
  const [copiedText, setCopiedText] = useState('');

  const handleCopy = (text) => {
    navigator.clipboard.writeText(text);
    setCopiedText(text);
    setTimeout(() => setCopiedText(''), 2000);
  };

  const generatePassword = () => {
    let chars = '';
    if (useUpper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (useLower) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (useNumbers) chars += '0123456789';
    if (useSymbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';

    if (!chars) {
      setPassword('Pilih minimal satu kriteria!');
      setPwStrength('Sangat Lemah');
      return;
    }

    let result = '';
    for (let i = 0; i < length; i++) {
      result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setPassword(result);

    // Calculate strength
    let score = 0;
    if (length >= 8) score += 1;
    if (length >= 14) score += 1;
    if (useUpper) score += 1;
    if (useLower) score += 1;
    if (useNumbers) score += 1;
    if (useSymbols) score += 1;

    if (score <= 2) setPwStrength('Lemah 🔴');
    else if (score <= 4) setPwStrength('Sedang 🟡');
    else setPwStrength('Sangat Kuat 🟢');
  };

  const generateUUID = () => {
    const list = [];
    for (let j = 0; j < uuidCount; j++) {
      let d = new Date().getTime();
      const uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, (c) => {
        const r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
      });
      list.push(uuid);
    }
    setUuidList(list);
  };

  const generateLorem = () => {
    const loremDb = [
      "Inzaghi's Sites merupakan gerbang layanan terpadu yang didesain secara adaptif untuk melayani kebutuhan komputasi ringan, kalkulasi, pemformatan kode, dan transformasi data. Dibangun di atas fondasi React modern dan Tailwind CSS v4, platform ini memberikan responsivitas visual terbaik.",
      "Teknologi modern menuntut kecepatan dan ketepatan informasi. Inzaghi's Group berkomitmen menciptakan perangkat lunak micro-utilities yang tangguh, mempercepat alur kerja pengembang maupun pengguna awam di Indonesia.",
      "Kalkulasi ilmiah, konversi bilangan desimal ke biner, format beautifikasi JSON terstruktur, dan pembuatan kunci sandi dengan entropi tinggi kini dapat diakses dalam satu dasbor terpadu. Selamat mencoba fitur-fitur tangguh kami.",
      "Semangat kolaborasi digital adalah nyawa dari Inzaghi's Sites. Terus berinovasi, merancang arsitektur web yang modular, dan menguji fungsionalitas algoritma secara real-time demi pengalaman terbaik pelanggan.",
      "Dengan mengedepankan filosofi keindahan visual, tipografi presisi Space Grotesk dan Inter berpadu harmonis menciptakan suasana tenang, produktif, dan futuristik dalam setiap baris kode yang dieksekusi."
    ];

    const paragraphs = [];
    for (let i = 0; i < paragraphsCount; i++) {
      paragraphs.push(loremDb[i % loremDb.length]);
    }
    setLoremParagraphs(paragraphs);
  };

  return (
    <div id="generator-root" className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 max-w-xl mx-auto">
      {/* Tabs */}
      <div className="flex border-b border-slate-100 mb-6 pb-2">
        {['password', 'uuid', 'lorem'].map((tab) => (
          <button
            key={tab}
            id={`tab-gen-${tab}`}
            onClick={() => setActiveTab(tab)}
            className={`flex-1 pb-3 text-sm font-semibold transition-all border-b-2 capitalize ${
              activeTab === tab
                ? 'border-emerald-500 text-emerald-600 font-bold'
                : 'border-transparent text-slate-400 hover:text-slate-600'
            }`}
          >
            {tab === 'password' ? 'Sandi' : tab === 'uuid' ? 'UUID' : 'Lorem Ipsum'}
          </button>
        ))}
      </div>

      {activeTab === 'password' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide">Pembuat Sandi Kuat</h3>
            <span className="text-xs bg-slate-100 text-slate-600 px-2.5 py-1 rounded-full font-semibold">
              Kekuatan: {pwStrength || 'N/A'}
            </span>
          </div>

          {password && (
            <div className="flex items-center justify-between bg-slate-50 border border-slate-200 rounded-xl p-4">
              <span id="generated-password-text" className="font-mono text-base font-bold text-slate-800 break-all">{password}</span>
              <button
                id="copy-pw-btn"
                onClick={() => handleCopy(password)}
                className="ml-3 p-2 bg-white hover:bg-slate-100 border border-slate-200 rounded-xl text-slate-600 transition-colors"
                title="Copy Password"
              >
                {copiedText === password ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          )}

          <div className="space-y-3 pt-2">
            <div>
              <div className="flex justify-between text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                <span>Panjang Karakter</span>
                <span>{length} Karakter</span>
              </div>
              <input
                id="pw-length-slider"
                type="range"
                min="6"
                max="32"
                value={length}
                onChange={(e) => setLength(parseInt(e.target.value))}
                className="w-full accent-emerald-500 cursor-pointer h-1.5 bg-slate-100 rounded-lg"
              />
            </div>

            <div className="grid grid-cols-2 gap-3 pt-2">
              <label className="flex items-center gap-2 text-xs font-medium text-slate-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={useUpper}
                  onChange={(e) => setUseUpper(e.target.checked)}
                  className="rounded text-emerald-500 focus:ring-emerald-500"
                />
                Huruf Kapital (A-Z)
              </label>

              <label className="flex items-center gap-2 text-xs font-medium text-slate-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={useLower}
                  onChange={(e) => setUseLower(e.target.checked)}
                  className="rounded text-emerald-500 focus:ring-emerald-500"
                />
                Huruf Kecil (a-z)
              </label>

              <label className="flex items-center gap-2 text-xs font-medium text-slate-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={useNumbers}
                  onChange={(e) => setUseNumbers(e.target.checked)}
                  className="rounded text-emerald-500 focus:ring-emerald-500"
                />
                Angka (0-9)
              </label>

              <label className="flex items-center gap-2 text-xs font-medium text-slate-600 cursor-pointer">
                <input
                  type="checkbox"
                  checked={useSymbols}
                  onChange={(e) => setUseSymbols(e.target.checked)}
                  className="rounded text-emerald-500 focus:ring-emerald-500"
                />
                Simbol (!@#$)
              </label>
            </div>
          </div>

          <button
            id="generate-pw-btn"
            onClick={generatePassword}
            className="w-full mt-4 flex items-center justify-center gap-2 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl transition-all shadow-sm"
          >
            <ShieldCheck className="w-4 h-4" /> Sandi Acak Baru
          </button>
        </div>
      )}

      {activeTab === 'uuid' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide">Pembuat UUID v4</h3>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Jumlah:</span>
              <input
                id="uuid-count-input"
                type="number"
                min="1"
                max="10"
                value={uuidCount}
                onChange={(e) => setUuidCount(parseInt(e.target.value) || 1)}
                className="w-14 px-2 py-1 text-xs border rounded bg-white text-slate-800"
              />
            </div>
          </div>

          {uuidList.length > 0 && (
            <div className="space-y-2 max-h-60 overflow-y-auto">
              {uuidList.map((id, index) => (
                <div key={index} className="flex items-center justify-between bg-slate-50 border border-slate-100 rounded-xl px-4 py-2.5">
                  <span className="font-mono text-xs font-semibold text-slate-600 break-all">{id}</span>
                  <button
                    onClick={() => handleCopy(id)}
                    className="p-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-slate-600 transition-colors"
                  >
                    {copiedText === id ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                  </button>
                </div>
              ))}
            </div>
          )}

          <button
            id="generate-uuid-btn"
            onClick={generateUUID}
            className="w-full mt-4 flex items-center justify-center gap-2 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl transition-all shadow-sm"
          >
            <Shuffle className="w-4 h-4" /> Generasikan UUID
          </button>
        </div>
      )}

      {activeTab === 'lorem' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide">Pembuat Teks Lorem Ipsum</h3>
            <div className="flex items-center gap-2">
              <span className="text-xs text-slate-500 font-medium">Paragraf:</span>
              <input
                id="lorem-count-input"
                type="number"
                min="1"
                max="5"
                value={paragraphsCount}
                onChange={(e) => setParagraphsCount(parseInt(e.target.value) || 1)}
                className="w-14 px-2 py-1 text-xs border rounded bg-white text-slate-800"
              />
            </div>
          </div>

          {loremParagraphs.length > 0 && (
            <div className="space-y-3 bg-slate-50 border border-slate-100 rounded-xl p-4 max-h-72 overflow-y-auto">
              {loremParagraphs.map((para, i) => (
                <p key={i} className="text-xs text-slate-600 leading-relaxed font-normal">{para}</p>
              ))}
              <div className="flex justify-end pt-2">
                <button
                  id="copy-lorem-btn"
                  onClick={() => handleCopy(loremParagraphs.join('\n\n'))}
                  className="flex items-center gap-1.5 px-3 py-1.5 bg-white hover:bg-slate-100 border border-slate-200 rounded-lg text-xs font-semibold text-slate-600 transition-colors"
                >
                  {copiedText === loremParagraphs.join('\n\n') ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                      Tersalin
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      Salin Semua
                    </>
                  )}
                </button>
              </div>
            </div>
          )}

          <button
            id="generate-lorem-btn"
            onClick={generateLorem}
            className="w-full mt-4 flex items-center justify-center gap-2 py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold rounded-xl transition-all shadow-sm"
          >
            <Shuffle className="w-4 h-4" /> Generasikan Teks
          </button>
        </div>
      )}
    </div>
  );
}
