import React, { useState } from 'react';
import { FileCode, Check, AlertTriangle } from 'lucide-react';

export default function FormatterTool() {
  const [inputCode, setInputCode] = useState('{\n  "name": "Inzaghi\'s Sites",\n  "status": "online",\n  "version": "v4.0-react",\n  "services": ["Calculators", "Converters", "Generators", "Formatters"]\n}');
  const [outputCode, setOutputCode] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  const handleFormat = () => {
    setErrorMsg('');
    setSuccessMsg('');
    try {
      if (!inputCode.trim()) {
        setOutputCode('');
        return;
      }
      const parsed = JSON.parse(inputCode);
      const formatted = JSON.stringify(parsed, null, 2);
      setOutputCode(formatted);
      setSuccessMsg('JSON Valid & Berhasil Diformat! ✨');
    } catch (err) {
      setErrorMsg(`JSON Tidak Valid: ${err.message}`);
      setOutputCode('');
    }
  };

  const handleMinify = () => {
    setErrorMsg('');
    setSuccessMsg('');
    try {
      if (!inputCode.trim()) {
        setOutputCode('');
        return;
      }
      const parsed = JSON.parse(inputCode);
      const minified = JSON.stringify(parsed);
      setOutputCode(minified);
      setSuccessMsg('JSON Valid & Berhasil Diminimalkan (Minified)! ✨');
    } catch (err) {
      setErrorMsg(`JSON Tidak Valid: ${err.message}`);
      setOutputCode('');
    }
  };

  const handleClear = () => {
    setInputCode('');
    setOutputCode('');
    setErrorMsg('');
    setSuccessMsg('');
  };

  const handleCopy = () => {
    if (!outputCode) return;
    navigator.clipboard.writeText(outputCode);
    setSuccessMsg('Hasil berhasil disalin ke clipboard! 📋');
    setTimeout(() => setSuccessMsg(''), 3000);
  };

  return (
    <div id="formatter-root" className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 max-w-2xl mx-auto">
      <div className="flex items-center gap-2 mb-4 border-b border-slate-100 pb-3">
        <FileCode className="w-5 h-5 text-emerald-500" />
        <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide">JSON Formatter & Validator</h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Input area */}
        <div className="flex flex-col">
          <label className="text-xs font-semibold text-slate-500 mb-1.5 uppercase">Input JSON Raw</label>
          <textarea
            id="formatter-input"
            rows={10}
            value={inputCode}
            onChange={(e) => setInputCode(e.target.value)}
            placeholder="Masukkan JSON mentah di sini..."
            className="w-full flex-1 p-3 font-mono text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
          />
        </div>

        {/* Output area */}
        <div className="flex flex-col">
          <label className="text-xs font-semibold text-slate-500 mb-1.5 uppercase">Hasil Output</label>
          <textarea
            id="formatter-output"
            rows={10}
            readOnly
            value={outputCode}
            placeholder="Hasil format akan muncul di sini..."
            className="w-full flex-1 p-3 font-mono text-xs bg-slate-900 text-emerald-400 border border-slate-800 rounded-xl focus:outline-none"
          />
        </div>
      </div>

      {/* Messages */}
      {errorMsg && (
        <div className="mt-4 p-3 bg-rose-50 border border-rose-100 text-rose-600 rounded-xl text-xs flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 shrink-0 mt-0.5" />
          <span className="font-semibold">{errorMsg}</span>
        </div>
      )}

      {successMsg && (
        <div className="mt-4 p-3 bg-emerald-50 border border-emerald-100 text-emerald-700 rounded-xl text-xs flex items-start gap-2">
          <Check className="w-4 h-4 shrink-0 mt-0.5" />
          <span className="font-semibold">{successMsg}</span>
        </div>
      )}

      {/* Actions */}
      <div className="flex flex-wrap gap-2 mt-4 pt-3 border-t border-slate-100">
        <button
          id="formatter-format-btn"
          onClick={handleFormat}
          className="px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow-sm transition-colors uppercase"
        >
          Format (Beautify)
        </button>
        <button
          id="formatter-minify-btn"
          onClick={handleMinify}
          className="px-4 py-2 bg-slate-700 hover:bg-slate-800 text-white font-bold text-xs rounded-xl shadow-sm transition-colors uppercase"
        >
          Minify
        </button>
        {outputCode && (
          <button
            id="formatter-copy-btn"
            onClick={handleCopy}
            className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl shadow-sm transition-colors uppercase"
          >
            Salin Hasil
          </button>
        )}
        <button
          id="formatter-clear-btn"
          onClick={handleClear}
          className="ml-auto px-4 py-2 text-rose-500 hover:bg-rose-50 font-bold text-xs rounded-xl transition-colors uppercase"
        >
          Bersihkan
        </button>
      </div>
    </div>
  );
}
