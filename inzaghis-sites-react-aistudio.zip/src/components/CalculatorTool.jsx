import React, { useState } from 'react';
import { Delete, HelpCircle } from 'lucide-react';

export default function CalculatorTool() {
  const [display, setDisplay] = useState('');
  const [prevVal, setPrevVal] = useState('');
  const [operation, setOperation] = useState('');
  const [clearOnNext, setClearOnNext] = useState(false);

  const handleNum = (num) => {
    if (clearOnNext) {
      setDisplay(num);
      setClearOnNext(false);
    } else {
      setDisplay(display === '0' ? num : display + num);
    }
  };

  const handleOperator = (op) => {
    if (display) {
      setPrevVal(display);
      setOperation(op);
      setClearOnNext(true);
    }
  };

  const handleClear = () => {
    setDisplay('');
    setPrevVal('');
    setOperation('');
  };

  const handleBackspace = () => {
    setDisplay(display.slice(0, -1));
  };

  const calculate = () => {
    if (!prevVal || !display || !operation) return;

    const prev = parseFloat(prevVal);
    const current = parseFloat(display);
    let result = 0;

    switch (operation) {
      case '+':
        result = prev + current;
        break;
      case '-':
        result = prev - current;
        break;
      case '*':
        result = prev * current;
        break;
      case '/':
        result = current !== 0 ? prev / current : 0;
        break;
      case '^':
        result = Math.pow(prev, current);
        break;
    }

    setDisplay(result.toString());
    setPrevVal('');
    setOperation('');
    setClearOnNext(true);
  };

  const handleScientific = (func) => {
    if (!display) return;
    const num = parseFloat(display);
    if (isNaN(num)) return;

    let result = 0;
    switch (func) {
      case 'sin':
        result = Math.sin((num * Math.PI) / 180);
        break;
      case 'cos':
        result = Math.cos((num * Math.PI) / 180);
        break;
      case 'tan':
        result = Math.tan((num * Math.PI) / 180);
        break;
      case 'sqrt':
        result = num >= 0 ? Math.sqrt(num) : 0;
        break;
      case 'ln':
        result = num > 0 ? Math.log(num) : 0;
        break;
      case 'sqr':
        result = num * num;
        break;
    }

    setDisplay(result.toFixed(6).replace(/\.?0+$/, ''));
    setClearOnNext(true);
  };

  return (
    <div id="calculator-root" className="bg-slate-900 text-white rounded-3xl shadow-xl border border-slate-800 p-6 max-w-sm mx-auto">
      {/* Screen */}
      <div className="mb-4 bg-slate-950/80 rounded-2xl p-4 text-right border border-slate-800/50">
        <div className="text-xs text-slate-500 font-mono h-5 overflow-hidden">
          {prevVal} {operation}
        </div>
        <div id="calculator-screen" className="text-3xl font-semibold font-mono tracking-tight text-emerald-400 break-all overflow-x-auto h-12">
          {display || '0'}
        </div>
      </div>

      {/* Keyboard Grid */}
      <div className="grid grid-cols-4 gap-2.5">
        {/* Scientific Row */}
        <button
          onClick={() => handleScientific('sin')}
          className="py-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-xs font-mono font-bold text-slate-300 transition-colors"
        >
          sin
        </button>
        <button
          onClick={() => handleScientific('cos')}
          className="py-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-xs font-mono font-bold text-slate-300 transition-colors"
        >
          cos
        </button>
        <button
          onClick={() => handleScientific('tan')}
          className="py-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-xs font-mono font-bold text-slate-300 transition-colors"
        >
          tan
        </button>
        <button
          onClick={() => handleScientific('sqrt')}
          className="py-3 rounded-xl bg-slate-800 hover:bg-slate-750 text-xs font-mono font-bold text-slate-300 transition-colors"
        >
          √x
        </button>

        {/* Action Row */}
        <button
          onClick={handleClear}
          className="py-3 rounded-xl bg-rose-500/10 hover:bg-rose-500/20 text-sm font-semibold text-rose-400 transition-colors border border-rose-500/20"
        >
          C
        </button>
        <button
          onClick={() => handleOperator('^')}
          className="py-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-sm font-semibold text-slate-300 transition-colors"
        >
          xʸ
        </button>
        <button
          onClick={handleBackspace}
          className="py-3 rounded-xl bg-slate-850 hover:bg-slate-800 flex items-center justify-center text-slate-300 transition-colors"
          title="Backspace"
        >
          <Delete className="w-4 h-4" />
        </button>
        <button
          onClick={() => handleOperator('/')}
          className="py-3 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 text-base font-bold transition-colors border border-emerald-500/20"
        >
          ÷
        </button>

        {/* Row 7 8 9 * */}
        <button
          onClick={() => handleNum('7')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          7
        </button>
        <button
          onClick={() => handleNum('8')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          8
        </button>
        <button
          onClick={() => handleNum('9')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          9
        </button>
        <button
          onClick={() => handleOperator('*')}
          className="py-4 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 text-base font-bold transition-colors border border-emerald-500/20"
        >
          ×
        </button>

        {/* Row 4 5 6 - */}
        <button
          onClick={() => handleNum('4')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          4
        </button>
        <button
          onClick={() => handleNum('5')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          5
        </button>
        <button
          onClick={() => handleNum('6')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          6
        </button>
        <button
          onClick={() => handleOperator('-')}
          className="py-4 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 text-base font-bold transition-colors border border-emerald-500/20"
        >
          -
        </button>

        {/* Row 1 2 3 + */}
        <button
          onClick={() => handleNum('1')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          1
        </button>
        <button
          onClick={() => handleNum('2')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          2
        </button>
        <button
          onClick={() => handleNum('3')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          3
        </button>
        <button
          onClick={() => handleOperator('+')}
          className="py-4 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 text-base font-bold transition-colors border border-emerald-500/20"
        >
          +
        </button>

        {/* Row +/- 0 . = */}
        <button
          onClick={() => {
            if (display) {
              if (display.startsWith('-')) setDisplay(display.slice(1));
              else setDisplay('-' + display);
            }
          }}
          className="py-4 rounded-xl bg-slate-850 hover:bg-slate-800 text-base transition-colors text-slate-300"
        >
          ±
        </button>
        <button
          onClick={() => handleNum('0')}
          className="py-4 rounded-xl bg-slate-800 hover:bg-slate-700 text-base font-medium transition-colors"
        >
          0
        </button>
        <button
          onClick={() => {
            if (!display.includes('.')) handleNum('.');
          }}
          className="py-4 rounded-xl bg-slate-850 hover:bg-slate-800 text-base transition-colors text-slate-300"
        >
          .
        </button>
        <button
          onClick={calculate}
          className="py-4 rounded-xl bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-lg transition-colors shadow-lg shadow-emerald-500/20"
        >
          =
        </button>
      </div>

      <div className="mt-4 text-center text-[10px] text-slate-500 flex items-center justify-center gap-1">
        <HelpCircle className="w-3 h-3" /> Sudut sin/cos/tan menggunakan satuan Derajat
      </div>
    </div>
  );
}
