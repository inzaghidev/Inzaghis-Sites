import React, { useState } from 'react';
import { BookOpen, Code, HelpCircle } from 'lucide-react';

const tutorialsData = [
  {
    id: 'js-basic',
    title: 'Dasar Pemrograman JavaScript',
    lang: 'JavaScript',
    content: 'JavaScript adalah bahasa pemrograman serbaguna yang menggerakkan interaktivitas web modern. Variabel dideklarasikan dengan let atau const, dan fungsi dideklarasikan dengan kata kunci function atau arrow function.',
    codeExample: 'const greeting = "Halo Inzaghi\'s Sites!";\nconsole.log(greeting);',
    quizQuestion: 'Manakah cara mendeklarasikan variabel konstanta yang tidak bisa diubah nilainya kembali di JavaScript?',
    quizOptions: ['let x = 10;', 'var x = 10;', 'const x = 10;', 'int x = 10;'],
    quizCorrect: 2
  },
  {
    id: 'react-components',
    title: 'Komponen & Props di React.js',
    lang: 'React.js',
    content: 'Komponen adalah elemen pembangun utama di React. Komponen adalah fungsi JavaScript yang mengembalikan JSX (JavaScript XML) dan menerima parameter berupa objek bernama props.',
    codeExample: 'function Welcome(props) {\n  return <h1>Halo, {props.name}!</h1>;\n}',
    quizQuestion: 'Bagaimana cara mengirimkan data (props) bernama "username" dengan nilai "inzaghi" ke komponen <Profile />?',
    quizOptions: ['<Profile username="inzaghi" />', '<Profile value="inzaghi" />', '<Profile props="inzaghi" />', '<Profile data={username: "inzaghi"} />'],
    quizCorrect: 0
  },
  {
    id: 'tailwind-basics',
    title: 'Responsive Layouts dengan Tailwind CSS v4',
    lang: 'Tailwind CSS',
    content: 'Tailwind CSS menggunakan pendekatan utility-first. Dengan menerapkan kelas-kelas seperti flex, grid, gap-4, p-6, dan responsive prefix (sm:, md:, lg:), Anda dapat mendesain visual web secara instan langsung di file JSX.',
    codeExample: '<div className="grid grid-cols-1 md:grid-cols-2 gap-4 p-6">\n  <div>Kolom 1</div>\n  <div>Kolom 2</div>\n</div>',
    quizQuestion: 'Prefix apakah yang digunakan di Tailwind CSS untuk menerapkan gaya di layar berukuran medium (tablet/laptop ke atas)?',
    quizOptions: ['sm:', 'md:', 'lg:', 'xl:'],
    quizCorrect: 1
  }
];

export default function TutorialPortal() {
  const [selectedIdx, setSelectedIdx] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState(null);
  const [quizChecked, setQuizChecked] = useState(false);
  const [quizResult, setQuizResult] = useState('');

  const current = tutorialsData[selectedIdx];

  const handleQuizCheck = () => {
    if (selectedAnswer === null) return;
    setQuizChecked(true);
    if (selectedAnswer === current.quizCorrect) {
      setQuizResult('Benar! Jawaban Anda tepat sekali! 🎉');
    } else {
      setQuizResult('Salah. Coba baca kembali penjelasannya! ❌');
    }
  };

  const handleNext = () => {
    setSelectedIdx((prev) => (prev + 1) % tutorialsData.length);
    setSelectedAnswer(null);
    setQuizChecked(false);
    setQuizResult('');
  };

  return (
    <div id="tutorial-portal-root" className="bg-white rounded-2xl shadow-sm border border-slate-100 p-6 max-w-xl mx-auto">
      <div className="flex items-center gap-2 mb-4 border-b border-slate-100 pb-3">
        <BookOpen className="w-5 h-5 text-emerald-500" />
        <h3 className="text-sm font-bold text-slate-700 uppercase tracking-wide">Pusat Belajar IT & Pemrograman</h3>
      </div>

      <div className="flex flex-wrap gap-1.5 mb-4">
        {tutorialsData.map((t, index) => (
          <button
            key={t.id}
            onClick={() => {
              setSelectedIdx(index);
              setSelectedAnswer(null);
              setQuizChecked(false);
              setQuizResult('');
            }}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
              selectedIdx === index ? 'bg-slate-900 text-white' : 'bg-slate-50 text-slate-600 hover:bg-slate-100'
            }`}
          >
            {t.lang}
          </button>
        ))}
      </div>

      <div className="space-y-4">
        <div>
          <h4 className="text-base font-bold text-slate-800 tracking-tight">{current.title}</h4>
          <p className="text-xs text-slate-600 mt-2 leading-relaxed font-normal">{current.content}</p>
        </div>

        {/* Code Block */}
        <div className="bg-slate-900 rounded-xl p-4 border border-slate-800">
          <div className="flex justify-between items-center mb-2">
            <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider font-mono">{current.lang} Snippet</span>
            <Code className="w-3.5 h-3.5 text-emerald-400" />
          </div>
          <pre className="font-mono text-xs text-emerald-400 overflow-x-auto whitespace-pre-wrap">{current.codeExample}</pre>
        </div>

        {/* Quiz Area */}
        <div className="bg-slate-50 border border-slate-100 rounded-xl p-4">
          <div className="flex items-center gap-1.5 mb-2">
            <HelpCircle className="w-4 h-4 text-emerald-600" />
            <span className="text-xs font-bold text-slate-700">Kuis Pengetahuan Singkat</span>
          </div>
          <p className="text-xs font-semibold text-slate-600 mb-3">{current.quizQuestion}</p>
          
          <div className="space-y-2">
            {current.quizOptions.map((opt, i) => (
              <label
                key={i}
                className={`flex items-center gap-2.5 px-3 py-2 border rounded-lg text-xs font-medium cursor-pointer transition-all ${
                  selectedAnswer === i
                    ? 'border-emerald-500 bg-emerald-500/5 text-emerald-700'
                    : 'border-slate-200 bg-white hover:bg-slate-50 text-slate-700'
                }`}
              >
                <input
                  type="radio"
                  name="quiz"
                  checked={selectedAnswer === i}
                  onChange={() => {
                    if (!quizChecked) setSelectedAnswer(i);
                  }}
                  disabled={quizChecked}
                  className="rounded-full text-emerald-500 focus:ring-emerald-500"
                />
                {opt}
              </label>
            ))}
          </div>

          {selectedAnswer !== null && !quizChecked && (
            <button
              onClick={handleQuizCheck}
              className="mt-4 px-4 py-2 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-lg transition-colors uppercase shadow-sm"
            >
              Kirim Jawaban
            </button>
          )}

          {quizResult && (
            <div className={`mt-3 p-3 rounded-lg text-xs font-bold ${
              quizResult.includes('Benar') ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
            }`}>
              {quizResult}
            </div>
          )}
        </div>

        <div className="flex justify-between items-center pt-2">
          <span className="text-[10px] text-slate-400 font-semibold uppercase">Langkah {selectedIdx + 1} dari {tutorialsData.length}</span>
          <button
            onClick={handleNext}
            className="px-3 py-1.5 border border-slate-200 rounded-lg text-xs font-bold text-slate-700 bg-white hover:bg-slate-50 transition-all uppercase"
          >
            Topik Selanjutnya
          </button>
        </div>
      </div>
    </div>
  );
}
