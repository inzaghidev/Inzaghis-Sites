import React from "react";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "motion/react";
import { Check } from "lucide-react";

import { portalsList, appsList, profileAbout } from "../data";
import Home from "../pages/Home";
import PortalViewData from "../components/layout/PortalViewData";
import AppViewData from "../components/layout/AppViewData";

/**
 * AppRouter — centralised route definitions for Inzaghi's Sites.
 *
 * Props forwarded from App:
 *   - contactName, setContactName, contactEmail, setContactEmail,
 *     contactSubject, setContactSubject, contactMsg, setContactMsg,
 *     contactSuccess, handleContactSubmit
 *   - emailInput, setEmailInput, passwordInput, setPasswordInput,
 *     loginNameInput, setLoginNameInput
 *   - handleLogin, handleRegister
 *   - showToast
 */
export default function AppRouter({
  // Contact form
  contactName,
  setContactName,
  contactEmail,
  setContactEmail,
  contactSubject,
  setContactSubject,
  contactMsg,
  setContactMsg,
  contactSuccess,
  handleContactSubmit,
  // Auth form
  emailInput,
  setEmailInput,
  passwordInput,
  setPasswordInput,
  loginNameInput,
  setLoginNameInput,
  handleLogin,
  handleRegister,
  // Utility
  showToast,
}) {
  const location = useLocation();

  return (
    <AnimatePresence mode="wait">
      <Routes location={location} key={location.pathname}>
        {/* HOME VIEW */}
        <Route path="/" element={<Home />} />

        {/* PORTALS VIEW */}
        <Route
          path="/portals"
          element={
            <PortalViewData
              portalsList={portalsList}
              showToast={showToast}
            />
          }
        />
        <Route
          path="/portals/:portalId"
          element={
            <PortalViewData
              portalsList={portalsList}
              showToast={showToast}
            />
          }
        />

        {/* APPS VIEW */}
        <Route path="/apps" element={<AppViewData appsList={appsList} />} />
        <Route
          path="/apps/:appId"
          element={<AppViewData appsList={appsList} />}
        />

        {/* BLOGS VIEW */}
        <Route
          path="/blogs"
          element={
            <motion.section
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              id="blogs-view-container"
              className="space-y-8"
            >
              <div className="text-left space-y-2">
                <h2 className="text-3xl font-black font-display text-slate-900 tracking-tight">
                  Inzaghi's Group Blogs
                </h2>
                <p className="text-xs md:text-sm text-slate-500 max-w-2xl leading-relaxed">
                  Platform penyedia artikel sains, wawasan teknik komputer,
                  tutorial teknologi, dan rilis resmi berita internal Poshaf
                  Media Group.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
                <div className="bg-white border border-slate-200/60 rounded-3xl p-6 text-left space-y-4 hover:shadow-md transition-all">
                  <span className="text-[9px] font-extrabold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
                    Teknologi
                  </span>
                  <h3 className="text-base font-bold text-slate-800 leading-snug">
                    Migrasi Besar-besaran ke React v19 &amp; Tailwind CSS v4
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-normal">
                    Panduan teknis bagaimana kami merombak keseluruhan sasis
                    Inzaghi's Sites dari PHP monolitik ke arsitektur
                    component-based React JSX.
                  </p>
                  <div className="text-[10px] font-bold text-slate-400">
                    Dipublikasikan 2 minggu yang lalu
                  </div>
                </div>

                <div className="bg-white border border-slate-200/60 rounded-3xl p-6 text-left space-y-4 hover:shadow-md transition-all">
                  <span className="text-[9px] font-extrabold text-sky-600 bg-sky-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
                    Sistem Operasi
                  </span>
                  <h3 className="text-base font-bold text-slate-800 leading-snug">
                    Mengapa Arch Linux Masih Menjadi Pilihan Server
                    Pengembang
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-normal">
                    Ulasan mendalam mengenai stabilitas rolling-release
                    distro GNU/Linux untuk menjalankan deployment
                    microservices skala industri kecil.
                  </p>
                  <div className="text-[10px] font-bold text-slate-400">
                    Dipublikasikan 1 bulan yang lalu
                  </div>
                </div>

                <div className="bg-white border border-slate-200/60 rounded-3xl p-6 text-left space-y-4 hover:shadow-md transition-all">
                  <span className="text-[9px] font-extrabold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
                    IoT &amp; Hardware
                  </span>
                  <h3 className="text-base font-bold text-slate-800 leading-snug">
                    Merancang Telemetri Rumah Cerdas dengan NodeMCU ESP8266
                  </h3>
                  <p className="text-xs text-slate-500 leading-relaxed font-normal">
                    Studi kasus pembuatan sensor suhu dan kelembaban ruangan
                    dengan enkripsi TLS, dikirim ke server Express pusat
                    secara realtime.
                  </p>
                  <div className="text-[10px] font-bold text-slate-400">
                    Dipublikasikan 2 bulan yang lalu
                  </div>
                </div>
              </div>
            </motion.section>
          }
        />

        {/* CONTACT VIEW */}
        <Route
          path="/contact"
          element={
            <motion.section
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              id="contact-view-container"
              className="max-w-xl mx-auto"
            >
              <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-sm text-left">
                <div className="space-y-2 mb-6">
                  <h2 className="text-2xl font-black font-display text-slate-900 tracking-tight">
                    Hubungi Kami
                  </h2>
                  <p className="text-xs text-slate-500 leading-relaxed font-normal">
                    Kirimkan pertanyaan, saran kerja sama, atau keluhan
                    teknis mengenai layanan Inzaghi's Sites kepada tim
                    administrator kami.
                  </p>
                </div>

                {contactSuccess ? (
                  <motion.div
                    initial={{ scale: 0.95, opacity: 0 }}
                    animate={{ scale: 1, opacity: 1 }}
                    className="bg-emerald-50 border border-emerald-100 rounded-2xl p-6 text-center space-y-3"
                  >
                    <Check className="w-12 h-12 text-emerald-500 mx-auto" />
                    <h3 className="text-base font-bold text-emerald-800">
                      Pesan Terkirim dengan Sukses!
                    </h3>
                    <p className="text-xs text-emerald-700 max-w-sm mx-auto leading-relaxed">
                      Terima kasih sudah menghubungi Inzaghi's Sites. Tim
                      kami akan segera menanggapi surel Anda dalam waktu
                      maksimal 24 jam kerja.
                    </p>
                  </motion.div>
                ) : (
                  <form
                    onSubmit={handleContactSubmit}
                    className="space-y-4"
                  >
                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                        Nama Lengkap
                      </label>
                      <input
                        type="text"
                        required
                        value={contactName}
                        onChange={(e) => setContactName(e.target.value)}
                        className="w-full px-4 py-2.5 text-xs font-medium rounded-xl border border-slate-200 bg-white text-slate-850 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        placeholder="Contoh: Budi Santoso"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                        Alamat Email
                      </label>
                      <input
                        type="email"
                        required
                        value={contactEmail}
                        onChange={(e) => setContactEmail(e.target.value)}
                        className="w-full px-4 py-2.5 text-xs font-medium rounded-xl border border-slate-200 bg-white text-slate-850 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        placeholder="Contoh: budi@domain.com"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                        Subjek / Topik
                      </label>
                      <input
                        type="text"
                        value={contactSubject}
                        onChange={(e) => setContactSubject(e.target.value)}
                        className="w-full px-4 py-2.5 text-xs font-medium rounded-xl border border-slate-200 bg-white text-slate-850 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        placeholder="Contoh: Kerja Sama Bisnis / Laporan Masalah"
                      />
                    </div>

                    <div>
                      <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                        Isi Pesan
                      </label>
                      <textarea
                        required
                        rows={5}
                        value={contactMsg}
                        onChange={(e) => setContactMsg(e.target.value)}
                        className="w-full px-4 py-3 text-xs font-medium rounded-xl border border-slate-200 bg-white text-slate-850 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                        placeholder="Ketikkan pesan detail Anda di sini..."
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow transition-all uppercase"
                    >
                      Kirim Pesan Surel
                    </button>
                  </form>
                )}
              </div>
            </motion.section>
          }
        />

        {/* ABOUT & DEVELOPER PROFILE VIEW */}
        {["/about", "/profile"].map((path) => (
          <Route
            key={path}
            path={path}
            element={
              <motion.section
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.3 }}
                id="about-view-container"
                className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start"
              >
                {/* Left Column Profile Card */}
                <div className="lg:col-span-4 bg-white border border-emerald-500 rounded-3xl p-6 shadow-sm text-center flex flex-col items-center">
                  {/* Photo Portrait Frame */}
                  <div className="w-40 h-48 rounded-2xl overflow-hidden border border-slate-100 shadow-inner mb-4">
                    <img
                      src="/images/inzaghi-posuma-alkahfi.jpg"
                      alt="Inzaghi Posuma Al Kahfi Software Developer Portrait"
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                    />
                  </div>

                  {/* Identity info */}
                  <h3 className="font-display font-extrabold text-xl text-slate-900 leading-tight">
                    Inzaghi Posuma Al Kahfi
                  </h3>
                  <span className="text-xs font-semibold text-blue-600 mt-1 uppercase tracking-wider block">
                    Software Developer
                  </span>

                  {/* Left profile action buttons */}
                  <div className="flex gap-2.5 my-5 w-full">
                    <a
                      href="/contact"
                      className="flex-1 py-2.5 bg-blue-600 hover:bg-blue-700 text-white font-bold text-xs rounded-xl transition-all shadow-sm block text-center"
                    >
                      Contact
                    </a>
                    <a
                      href="https://github.com/inzaghidev"
                      target="_blank"
                      rel="noreferrer"
                      className="flex-1 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl text-center border border-slate-200 transition-all block"
                    >
                      Portofolio
                    </a>
                  </div>

                  <hr className="w-full border-slate-100 mb-4" />

                  {/* Skills Section */}
                  <div className="w-full text-left mb-6">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-2">
                      SKILLS
                    </span>
                    <p className="text-xs font-semibold text-slate-700 leading-relaxed">
                      JavaScript React Node.js HTML/CSS Tailwind Css
                    </p>
                  </div>

                  {/* Education Section */}
                  <div className="w-full text-left space-y-4">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest block mb-1">
                      EDUCATION
                    </span>

                    <div>
                      <h4 className="text-xs font-bold text-slate-800">
                        Information Technology
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Pradita University
                      </p>
                      <p className="text-[10px] font-bold text-slate-400">
                        2021 - 2025
                      </p>
                    </div>

                    <div>
                      <h4 className="text-xs font-bold text-slate-800">
                        Science Studies
                      </h4>
                      <p className="text-[11px] text-slate-500">
                        Islamic Village High School
                      </p>
                      <p className="text-[10px] font-bold text-slate-400">
                        2018 - 2021
                      </p>
                    </div>
                  </div>
                </div>

                {/* Right Column Experience & Description */}
                <div className="lg:col-span-8 bg-white border border-emerald-500 rounded-3xl p-6 md:p-8 shadow-sm text-left space-y-6">
                  {/* About Me Details */}
                  <div className="space-y-3">
                    <h2 className="text-2xl font-black font-display text-slate-900 tracking-tight">
                      About Me
                    </h2>
                    <p className="text-xs text-slate-600 leading-relaxed font-normal">
                      {profileAbout.aboutText}
                    </p>
                  </div>

                  {/* Socials Connection */}
                  <div className="flex flex-col items-center py-2">
                    <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-3">
                      Find me on
                    </span>
                    <div className="flex gap-4">
                      <a
                        href="https://linkedin.com"
                        target="_blank"
                        rel="noreferrer"
                        className="text-slate-600 hover:text-blue-600 transition-colors"
                      >
                        <svg
                          className="w-5 h-5 fill-current"
                          viewBox="0 0 24 24"
                        >
                          <path d="M19 0h-14c-2.761 0-5 2.239-5 5v14c0 2.761 2.239 5 5 5h14c2.762 0 5-2.239 5-5v-14c0-2.761-2.238-5-5-5zm-11 19h-3v-11h3v11zm-1.5-12.268c-.966 0-1.75-.779-1.75-1.75s.784-1.75 1.75-1.75 1.75.779 1.75 1.75-.784 1.75-1.75 1.75zm13.5 12.268h-3v-5.604c0-3.368-4-3.113-4 0v5.604h-3v-11h3v1.765c1.396-2.586 7-2.777 7 2.476v6.759z" />
                        </svg>
                      </a>
                      <a
                        href="https://youtube.com"
                        target="_blank"
                        rel="noreferrer"
                        className="text-slate-600 hover:text-red-600 transition-colors"
                      >
                        <svg
                          className="w-5 h-5 fill-current"
                          viewBox="0 0 24 24"
                        >
                          <path d="M23.498 6.163a3.003 3.003 0 0 0-2.11-2.11C19.517 3.545 12 3.545 12 3.545s-7.517 0-9.388.508a3.003 3.003 0 0 0-2.11 2.11C0 8.033 0 12 0 12s0 3.967.502 5.837a3.003 3.003 0 0 0 2.11 2.11c1.871.508 9.388.508 9.388.508s7.517 0 9.388-.508a3.003 3.003 0 0 0 2.11-2.11C24 15.967 24 12 24 12s0-3.967-.502-5.837zM9.545 15.568V8.432L15.818 12l-6.273 3.568z" />
                        </svg>
                      </a>
                      <a
                        href="https://facebook.com"
                        target="_blank"
                        rel="noreferrer"
                        className="text-slate-600 hover:text-blue-700 transition-colors"
                      >
                        <svg
                          className="w-5 h-5 fill-current"
                          viewBox="0 0 24 24"
                        >
                          <path d="M9 8h-3v4h3v12h5v-12h3.642l.358-4h-4v-1.667c0-.955.192-1.333 1.115-1.333h2.885v-5h-3.808c-3.596 0-5.192 1.583-5.192 4.615v3.385z" />
                        </svg>
                      </a>
                      <a
                        href="https://instagram.com"
                        target="_blank"
                        rel="noreferrer"
                        className="text-slate-600 hover:text-pink-600 transition-colors"
                      >
                        <svg
                          className="w-5 h-5 fill-current"
                          viewBox="0 0 24 24"
                        >
                          <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zm0-2c-3.259 0-3.667.014-4.947.072-4.358.2-6.78 2.618-6.98 6.98-.059 1.281-.073 1.689-.073 4.948 0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98-1.281-.059-1.69-.073-4.949-.073zm0 5.838c-3.403 0-6.162 2.759-6.162 6.162s2.759 6.163 6.162 6.163 6.162-2.759 6.162-6.163c0-3.403-2.759-6.162-6.162-6.162zm0 10.162c-2.209 0-4-1.79-4-4 0-2.209 1.791-4 4-4s4 1.791 4 4c0 2.21-1.791 4-4 4zm6.406-11.845c-.796 0-1.441.645-1.441 1.44s.645 1.44 1.441 1.44c.795 0 1.439-.645 1.439-1.44s-.644-1.44-1.439-1.44z" />
                        </svg>
                      </a>
                    </div>
                  </div>

                  <hr className="w-full border-slate-100" />

                  {/* Experience History */}
                  <div className="space-y-4">
                    <h3 className="text-sm font-black text-slate-400 uppercase tracking-widest">
                      Experience
                    </h3>

                    <div className="space-y-6">
                      {profileAbout.experience.map((exp, idx) => (
                        <div key={idx} className="space-y-1.5">
                          <div className="flex flex-wrap items-center justify-between gap-1">
                            <h4 className="text-base font-bold text-slate-900">
                              {exp.role}
                            </h4>
                            <span className="text-xs text-slate-500 font-bold">
                              {exp.company} &nbsp;|&nbsp; {exp.period}
                            </span>
                          </div>
                          <p className="text-xs text-slate-500 leading-relaxed font-normal">
                            {exp.description}
                          </p>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </motion.section>
            }
          />
        ))}

        {/* SIGN IN VIEW */}
        <Route
          path="/signin"
          element={
            <motion.section
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              id="signin-view-container"
              className="max-w-md mx-auto"
            >
              <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-md text-left">
                <div className="text-center space-y-2 mb-6">
                  <h2 className="text-2xl font-black font-display text-slate-900 tracking-tight">
                    Sign In
                  </h2>
                  <p className="text-xs text-slate-500 font-normal">
                    Masuk ke akun Inzaghi's Sites Anda untuk sinkronisasi
                    data utilitas.
                  </p>
                </div>

                <form
                  onSubmit={(e) => {
                    handleLogin(e);
                    if (emailInput && passwordInput) {
                      window.location.href = "/";
                    }
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                      Alamat Email
                    </label>
                    <input
                      type="email"
                      required
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      className="w-full px-4 py-2.5 text-xs font-medium rounded-xl border border-slate-200 bg-white text-slate-855 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      placeholder="Masukkan email Anda"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                      Kata Sandi (Password)
                    </label>
                    <input
                      type="password"
                      required
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      className="w-full px-4 py-2.5 text-xs font-medium rounded-xl border border-slate-200 bg-white text-slate-855 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      placeholder="••••••••"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-slate-950 hover:bg-slate-900 text-white font-bold text-xs rounded-xl shadow transition-all uppercase"
                  >
                    Masuk Akun
                  </button>
                </form>

                <div className="text-center mt-6">
                  <p className="text-xs text-slate-500 font-normal">
                    Belum punya akun?{" "}
                    <a
                      href="/register"
                      className="text-emerald-600 font-bold hover:underline"
                    >
                      Daftar Baru
                    </a>
                  </p>
                </div>
              </div>
            </motion.section>
          }
        />

        {/* REGISTER VIEW */}
        <Route
          path="/register"
          element={
            <motion.section
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.3 }}
              id="register-view-container"
              className="max-w-md mx-auto"
            >
              <div className="bg-white border border-slate-200 rounded-3xl p-6 md:p-8 shadow-md text-left">
                <div className="text-center space-y-2 mb-6">
                  <h2 className="text-2xl font-black font-display text-slate-900 tracking-tight">
                    Daftar Baru
                  </h2>
                  <p className="text-xs text-slate-500 font-normal">
                    Buat akun Inzaghi's Sites terpusat untuk mengakses semua
                    dasbor.
                  </p>
                </div>

                <form
                  onSubmit={(e) => {
                    handleRegister(e);
                    if (emailInput && passwordInput && loginNameInput) {
                      window.location.href = "/";
                    }
                  }}
                  className="space-y-4"
                >
                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                      Nama Lengkap
                    </label>
                    <input
                      type="text"
                      required
                      value={loginNameInput}
                      onChange={(e) => setLoginNameInput(e.target.value)}
                      className="w-full px-4 py-2.5 text-xs font-medium rounded-xl border border-slate-200 bg-white text-slate-855 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      placeholder="Contoh: Inzaghi Al Kahfi"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                      Alamat Email
                    </label>
                    <input
                      type="email"
                      required
                      value={emailInput}
                      onChange={(e) => setEmailInput(e.target.value)}
                      className="w-full px-4 py-2.5 text-xs font-medium rounded-xl border border-slate-200 bg-white text-slate-855 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      placeholder="nama@email.com"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-semibold text-slate-500 mb-1.5 uppercase">
                      Kata Sandi (Password)
                    </label>
                    <input
                      type="password"
                      required
                      value={passwordInput}
                      onChange={(e) => setPasswordInput(e.target.value)}
                      className="w-full px-4 py-2.5 text-xs font-medium rounded-xl border border-slate-200 bg-white text-slate-855 focus:outline-none focus:ring-1 focus:ring-emerald-500"
                      placeholder="Minimal 6 karakter"
                    />
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-emerald-500 hover:bg-emerald-600 text-white font-bold text-xs rounded-xl shadow transition-all uppercase"
                  >
                    Daftar Sekarang
                  </button>
                </form>

                <div className="text-center mt-6">
                  <p className="text-xs text-slate-500 font-normal">
                    Sudah memiliki akun?{" "}
                    <a
                      href="/signin"
                      className="text-emerald-600 font-bold hover:underline"
                    >
                      Login Saja
                    </a>
                  </p>
                </div>
              </div>
            </motion.section>
          }
        />

        <Route path="*" element={<Navigate to="/" replace />} />
      </Routes>
    </AnimatePresence>
  );
}
