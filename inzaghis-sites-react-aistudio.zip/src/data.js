export const portalsList = [
  {
    id: 'widgets',
    title: 'Widgets',
    category: 'Portals',
    description: 'Merupakan kumpulan Widget Serbaguna untuk Anda yang membutuhkan Informasi seakurat mungkin. Widget di sini juga termasuk yang sedang heboh saat ini.',
    iconType: 'widgets',
    bgColor: 'bg-rose-100',
  },
  {
    id: 'tutorials',
    title: 'Technology Tutorials',
    category: 'Portals',
    description: 'Merupakan kumpulan dari berbagai macam Teknologi apapun dalam bidang IT, dan sebagai Pembelajaran untuk berbagai macam Teknologi IT apapun seperti Pemrograman, Aplikasi, Ilmu Komputer, Analisis Data, dan lainnya.',
    iconType: 'tutorials',
    bgColor: 'bg-[#0f1d1f] text-white',
  },
  {
    id: 'materials',
    title: 'Learning Materials',
    category: 'Portals',
    description: 'Kumpulan materi pembelajaran, referensi tesis, riset, serta wawancara yang bermanfaat untuk mendukung akademis dan pengembangan profesional di bidang teknologi.',
    iconType: 'materials',
    bgColor: 'bg-blue-50',
  },
  {
    id: 'projects',
    title: 'Projects Showcase',
    category: 'Portals',
    description: 'Menampilkan berbagai proyek perangkat lunak, aplikasi web, dan kontribusi open source yang dikembangkan oleh Inzaghi dan kolaborator Inzaghi\'s Group.',
    iconType: 'projects',
    bgColor: 'bg-emerald-50',
  }
];

export const appsList = [
  {
    id: 'converters',
    title: 'Converters',
    category: 'Pages Apps',
    description: 'Merupakan portal untuk Aplikasi Konverter seperti Konversi Suhu, Massa (Berat), Panjang, Sistem Bilangan, dan lain-lain. Sebagian dari Aplikasi Konverter ini akan sedikit menggunakan API.',
    iconType: 'converters',
    bgColor: 'bg-pink-50',
  },
  {
    id: 'calculators',
    title: 'Calculators',
    category: 'Pages Apps',
    description: 'Merupakan kumpulan dari beberapa jenis Kalkulator seperti Kalkulator Sederhana, Ilmiah, Matematika, Kesehatan, Keuangan, hingga Kalkulator untuk Keseharian.',
    iconType: 'calculators',
    bgColor: 'bg-amber-50',
  },
  {
    id: 'generators',
    title: 'Generators',
    category: 'Pages Apps',
    description: 'Merupakan Aplikasi untuk membuat dan mengenerasi sesuatu seperti Text Generator hingga Image Generator, dan dapat dibuat secara acak.',
    iconType: 'generators',
    bgColor: 'bg-sky-50',
  },
  {
    id: 'formatters',
    title: 'Formatters',
    category: 'Pages Apps',
    description: 'Merupakan Aplikasi untuk melakukan Formatting seperti XML, JSON, dll, hingga melakukan Pemformatan apapun.',
    iconType: 'formatters',
    bgColor: 'bg-violet-50',
  }
];

export const profileAbout = {
  name: 'Inzaghi Posuma Al Kahfi',
  role: 'Software Developer',
  location: 'Tangerang, Banten, Indonesia',
  avatarUrl: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=400',
  aboutText: "I'm Inzaghi Posuma Al Kahfi, a Fresher Graduate in Information Technology Student at Pradita University (Tangerang, Banten, Indonesia) with hands-on experience in Web and Mobile Development, IoT Projects, and Data-driven Applications. I'm also a Passionate Software Engineer and Full-stack Developer with hands-on experience in Web and Mobile App Development, utilizing Laravel (PHP), React.js, Flutter (Dart), JavaScript, and Python. Candidate for Chief Executive Officer (CEO) of Inzaghi's Group (InzaTech Poshaf).",
  skills: [
    'JavaScript', 'React.js', 'Node.js', 'HTML/CSS', 'Tailwind Css', 'Flutter (Dart)', 'Laravel (PHP)', 'Python', 'IoT (Internet of Things)', 'MySQL / PostgreSQL'
  ],
  education: [
    {
      degree: 'Information Technology',
      institution: 'Pradita University',
      period: '2021 - 2025'
    },
    {
      degree: 'Science Studies',
      institution: 'Islamic Village High School',
      period: '2018 - 2021'
    }
  ],
  experience: [
    {
      role: 'Fullstack Web Developer',
      company: 'Inzaghi\'s Group (InzaTech)',
      period: '2023 - Present',
      description: 'Developing and designing various corporate and utility sites. Building robust web tools including unit converters, multi-functional calculators, developer formatters, and central network portal dashboards. Integrating React front-ends with solid secure APIs.'
    },
    {
      role: 'IoT Engineer Intern',
      company: 'Smart City Laboratory',
      period: '2022 - 2023',
      description: 'Designed and deployed environmental monitoring sensor nodes. Developed real-time telemetry dashboards using MQTT and Node.js for data collection and visual analytics.'
    },
    {
      role: 'Junior Web Developer',
      company: 'ABC Company',
      period: '2017 - 2019',
      description: 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. Donec pede justo, fringilla vel. Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes.'
    }
  ]
};
