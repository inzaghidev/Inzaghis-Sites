import { useState } from "react";
import { ThemeProvider } from "./context/ThemeContext";
import Navbar from "./components/layout/Navbar";
import Footer from "./components/layout/Footer";
import AppRouter from "./router/AppRouter.jsx";

export default function App() {
  const [activeDropdown, setActiveDropdown] = useState(null);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileDropdowns, setMobileDropdowns] = useState({
    blogs: false,
    portals: false,
    apps: false,
    about: false,
    group: false,
    switch: false,
  });
  const [user, setUser] = useState(null);
  const [legalModal, setLegalModal] = useState(null);

  const toggleMobileDropdown = (key) => {
    setMobileDropdowns((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const handleDropdownClick = (name) => {
    setActiveDropdown((prev) => (prev === name ? null : name));
  };

  const handleLogout = () => {
    setUser(null);
  };

  const showToast = (message) => {
    console.info(message);
  };

  return (
    <ThemeProvider>
      <div className="min-h-screen flex flex-col bg-slate-50">
        <Navbar
          activeDropdown={activeDropdown}
          setActiveDropdown={setActiveDropdown}
          mobileMenuOpen={mobileMenuOpen}
          setMobileMenuOpen={setMobileMenuOpen}
          toggleMobileDropdown={toggleMobileDropdown}
          mobileDropdowns={mobileDropdowns}
          user={user}
          handleLogout={handleLogout}
          showToast={showToast}
          handleDropdownClick={handleDropdownClick}
          setLegalModal={setLegalModal}
        />

        <main className="flex-1">
          <AppRouter showToast={showToast} setLegalModal={setLegalModal} />
        </main>

        <Footer
          setActiveView={() => {}}
          setSelectedAppId={() => {}}
          setSelectedPortalId={() => {}}
          setLegalModal={setLegalModal}
        />
      </div>
    </ThemeProvider>
  );
}
