import React from "react";
import { motion } from "motion/react";

export default function InzaTechBlog({ setActiveView }) {
  return (
    <motion.section
      key="blogs-view"
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3 }}
      id="blogs-view-container"
      className="space-y-8"
    >
      <div className="text-left space-y-2">
        <h2 className="text-3xl font-black font-display text-slate-900 tracking-tight">
          Inzaghi's Group Blogs
        </h2>
        <p className="text-xs md:text-sm text-slate-500 max-w-2xl leading-relaxed">
          Platform penyedia artikel sains, wawasan teknik komputer, tutorial
          teknologi, dan rilis resmi berita internal Poshaf Media Group.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
        <div className="bg-white border border-slate-200/60 rounded-3xl p-6 text-left space-y-4 hover:shadow-md transition-all">
          <span className="text-[9px] font-extrabold text-emerald-600 bg-emerald-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
            Teknologi
          </span>
          <h3 className="text-base font-bold text-slate-800 leading-snug">
            Migrasi Besar-besaran ke React v19 & Tailwind CSS v4
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed font-normal">
            Panduan teknis bagaimana kami merombak keseluruhan sasis Inzaghi's
            Sites dari PHP monolitik ke arsitektur component-based React JSX.
          </p>
          <div className="text-[10px] font-bold text-slate-400">
            Dipublikasikan 2 minggu yang lalu
          </div>
        </div>

        <div className="bg-white border border-slate-200/60 rounded-3xl p-6 text-left space-y-4 hover:shadow-md transition-all">
          <span className="text-[9px] font-extrabold text-sky-600 bg-sky-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
            Sistem Operasi
          </span>
          <h3 className="text-base font-bold text-slate-800 leading-snug">
            Mengapa Arch Linux Masih Menjadi Pilihan Server Pengembang
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed font-normal">
            Ulasan mendalam mengenai stabilitas rolling-release distro GNU/Linux
            untuk menjalankan deployment microservices skala industri kecil.
          </p>
          <div className="text-[10px] font-bold text-slate-400">
            Dipublikasikan 1 bulan yang lalu
          </div>
        </div>

        <div className="bg-white border border-slate-200/60 rounded-3xl p-6 text-left space-y-4 hover:shadow-md transition-all">
          <span className="text-[9px] font-extrabold text-amber-600 bg-amber-50 px-2.5 py-1 rounded-full uppercase tracking-wider">
            IoT & Hardware
          </span>
          <h3 className="text-base font-bold text-slate-800 leading-snug">
            Merancang Telemetri Rumah Cerdas dengan NodeMCU ESP8266
          </h3>
          <p className="text-xs text-slate-500 leading-relaxed font-normal">
            Studi kasus pembuatan sensor suhu dan kelembaban ruangan dengan
            enkripsi TLS, dikirim ke server Express pusat secara realtime.
          </p>
          <div className="text-[10px] font-bold text-slate-400">
            Dipublikasikan 2 bulan yang lalu
          </div>
        </div>
      </div>
    </motion.section>
  );
}
