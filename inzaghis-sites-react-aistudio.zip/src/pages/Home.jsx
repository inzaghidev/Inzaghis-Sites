import React from "react";
import { motion } from "motion/react";

export default function Home({ setActiveView }) {
  return (
    <main
      id="main-content"
      className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-8 md:py-14"
    >
      <motion.section
        key="home-view"
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        exit={{ opacity: 0, y: -15 }}
        transition={{ duration: 0.3 }}
        id="home-view-container"
        className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center"
      >
        <div className="lg:col-span-6 space-y-6 text-left">
          <h1
            id="welcome-heading"
            className="text-4xl md:text-5xl lg:text-[54px] font-black font-display text-slate-900 tracking-tight leading-none uppercase"
          >
            Welcome to <br />
            Inzaghi's Sites!
          </h1>

          <div className="space-y-4 text-slate-600 text-sm md:text-base leading-relaxed font-normal">
            <p>
              Inzaghi's Sites merupakan Platform Layanan Situs Web untuk dapat
              diakses ke semua layanan Inzaghi's Group.
            </p>
            <p>
              Inzaghi's Sites juga memudahkan Anda untuk mengakses Aplikasi dan
              Portal apapun yang berbasis Web seperti yang tersedia pada Portals
              and Apps seperti Widget, Tutorial Teknologi, Konverter,
              Kalkulator, Generator, dan lain-lainnya.
            </p>
          </div>

          <div className="pt-3">
            <button
              id="home-about-btn"
              onClick={() => setActiveView("about")}
              className="px-8 py-3.5 bg-[#17181c] text-white hover:bg-slate-800 text-[11px] font-black tracking-wider uppercase rounded-xl transition-all shadow-md hover:shadow-lg hover:-translate-y-0.5"
            >
              About
            </button>
          </div>
        </div>

        <div className="lg:col-span-6 flex justify-center">
          <div
            id="home-illustration-wrap"
            className="relative max-w-md md:max-w-xl w-full"
          >
            <div className="absolute inset-0 bg-emerald-500/5 blur-3xl rounded-full"></div>
            <img
              src="/src/assets/images/hero_illustration_1782792692652.jpg"
              alt="Inzaghis Sites Creative Tech Setup Workspace illustration"
              referrerPolicy="no-referrer"
              className="w-full h-auto rounded-3xl shadow-xl border border-slate-100 object-cover relative z-10 hover:scale-[1.01] transition-transform duration-300"
            />
          </div>
        </div>
      </motion.section>
    </main>
  );
}
