# Inzaghi's Sites

This Repository is for storing all Source Codes from Inzaghi's Sites.

![Inzaghi's Sites](/isites-php/images/inzaghis-sites-by-inzaghis-group-corp.png)

Link :

- [inzaghisites.000webhostapp.com (Old)](https://inzaghisites.000webhostapp.com)
- [inzaghi.wuaze.com (New)](https://inzaghi.wuaze.com)

## Inzaghi's Sites Homepage

Berikut ini adalah Tampilan Utama dari Inzaghi's Sites :

![Inzaghi's Sites Homepage](/isites-php/images/inzaghis-sites-homepage-202409.jpg)

## Inzaghi's Sites Page Apps

Tampilan Aplikasi dari Page Apps :

![Pages Apps Inzaghi's Sites](/isites-php/images/inzaghis-sites-pages-apps.png)
