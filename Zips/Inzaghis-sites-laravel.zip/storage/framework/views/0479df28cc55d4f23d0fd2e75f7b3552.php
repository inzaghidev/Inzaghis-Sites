<?php
    $webRoot = realpath(dirname(base_path())); // Laravel: base_path untuk root project
    $serverRoot = realpath($_SERVER['DOCUMENT_ROOT']);

    if ($webRoot === $serverRoot) {
        $pathToWebRoot = "";
    } else {
        $pathToWebRoot = substr($webRoot, strlen($serverRoot) + 1);
    }
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />

        <!-- Stylesheets -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('src/css/style.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('src/css/reset.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('components/navbar/navbar.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('components/footsite/footsite.css')); ?>">
        
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.6.2/css/bootstrap.min.css" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionimages/2.0.1/css/ionicons.min.css" />
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@500&display=swap" rel="stylesheet"> 

        <!-- Feather Icons -->
        <script src="https://unpkg.com/feather-icons"></script>

        <title><?php echo e($page_title ?? 'Default Title'); ?> - Inzaghi's Sites</title>
        
    </head>
    <body>
        <?php echo $__env->make('components.navbar.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('container'); ?>
        <?php echo $__env->make('components.footsite.footsite', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Inzaghis-Group-Projects\Inzaghi's Sites\Inzaghis-sites-laravel\resources\views/layouts/header.blade.php ENDPATH**/ ?>