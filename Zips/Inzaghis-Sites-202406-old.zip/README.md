# Inzaghi's Sites

This Repository is for storing all Source Codes from Inzaghi's Sites.

![Inzaghi's Sites](/Inzaghis-Sites-202406-old/isites-php/images/inzaghis-sites-by-inzaghis-group-corp.png)

Link : [inzaghisites.000webhostapp.com](https://inzaghisites.000webhostapp.com)

## Inzaghi's Sites Homepage

Berikut ini adalah Tampilan Utama dari Inzaghi's Sites :

![Inzaghi's Sites Homepage](/Inzaghis-Sites-202406-old/isites-php/images/inzaghis-sites-homepage-202401.png)

## Inzaghi's Sites Page Apps

Tampilan Aplikasi dari Page Apps :

![Pages Apps Inzaghi's Sites](/Inzaghis-Sites-202406-old/)

## Inzaghi's Sites Contact

Tampilan Aplikasi dari Contact :

![Contact Inzaghi's Sites](/Inzaghis-Sites-202406-old/)
