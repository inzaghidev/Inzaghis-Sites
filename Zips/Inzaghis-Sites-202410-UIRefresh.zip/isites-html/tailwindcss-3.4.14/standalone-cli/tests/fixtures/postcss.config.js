module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
    'postcss-will-change': {},
  },
}
