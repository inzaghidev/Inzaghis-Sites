import createPlugin from '../util/createPlugin'
export default createPlugin
