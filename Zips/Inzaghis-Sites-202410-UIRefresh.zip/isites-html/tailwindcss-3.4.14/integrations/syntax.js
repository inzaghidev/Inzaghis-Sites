// Small helper to allow for css, html and JavaScript highlighting / formatting in most editors.
module.exports = { css: String.raw, html: String.raw, javascript: String.raw }
