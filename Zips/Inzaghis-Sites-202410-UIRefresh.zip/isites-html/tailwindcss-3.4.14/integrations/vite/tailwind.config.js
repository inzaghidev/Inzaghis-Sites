module.exports = {
  content: ['./index.html', './glob/*.{js,html}'],
  theme: {
    extend: {},
  },
  corePlugins: {
    preflight: false,
  },
  plugins: [],
}
