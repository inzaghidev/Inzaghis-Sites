// content-[real-static-negative]
