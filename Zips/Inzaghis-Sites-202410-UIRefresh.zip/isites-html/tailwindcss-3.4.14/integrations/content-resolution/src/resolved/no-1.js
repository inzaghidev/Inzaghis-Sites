// content-[resolved-static-negative]
